#ifndef _OVER_CURRENT_MONITOR_H_
#define _OVER_CURRENT_MONITOR_H_



void InitOverCurrentMonitorTask(void);
void OverCurrentMonitorTask(void *op);


#endif



