
#include "include_all_headers.h"
#include "MainStateMachine.h"
#include "watchdog.h"
#include "selfTest.h"

//Reset function
#define TIME_BETWEEN_SWITCH 100
#define TIME_WHEN_ALL_CUSHIONS_OPEN 5000

#define STABILIZATION_DELAY 1000

	
//Version 14.x 	4/12/18


#define DATA_SAVE_TO_FLASH

// Cycle test with pump
#define AUTOMATIC_OPERATION 		0              

//Cycle test without pump
#define AUTOMATIC_VALVE_TEST 		0

#define TIME_BETWEEN_VALVE_SWITCH	1000


void SystemClock_Config(void);
void init_cushions_state(void);
void test_valve_cycle(void);


int main(void)
{
	uint16_t stab_delay = STABILIZATION_DELAY;
	//Init HAL driver
  HAL_Init();
	//Init system clock config
  SystemClock_Config();	
	//Init GPIO
	GpioInit();	
	//Init PWM module
	PwmInit();
	//Init GPIO task
	gpioInitTask();

	//Init ADC driver
	AdcInit();

	BatteryMonotorTask(NULL);
	//Init Battery monitor task
	InitBatteryMonitorTask();
	//Init USART driver
	InitUsart();

	//Read saved data from flash
	readDataFromFlash();
	
	//Init main controller task
	InitMainControllerTask();
	
	//Try to detect the test jig.
	if(testIsInJig())
	{
		testWaitForStart();
	}
	//Init LED Indication task
  InitLedIndicationTask();
	
	LedIndicationTask(NULL);
	
	set_led_operation_work(2);
	//Print message
	printf("Program starting...\r\nwait %d seconds...\r\n",stab_delay/1000);
	
	LedIndicationTask(NULL);
	//Wait few Sec
	//to filtering the first spike.
	HAL_Delay(stab_delay);	

	//Cycle test
	set_automatic_operation(AUTOMATIC_OPERATION);

	
	
	if(get_automatic_operation())
	{
			//If cycle test -> init all valves 
		init_cushions_state();		
	}else
	{	
		InitSaveDataToFlashTask();
		// read flash
		ReadCurrentCusionFromFlash();
		
		InitSleepModeTask();
	}

	
	if(getLoggStructPtr()->automaticOp)
	{
		getLoggStructPtr()->automaticOp = 0;
		//If cycle test -> init all valves 
		init_cushions_state();		
		saveDataToFlash();
		
	}
	init_watchdog(0);
	
	//Turn all LED's off
	gpio_set_pin(GPIO_SET_LOW,LED_GREEN_PORT,LED_GREEN_PIN);
	gpio_set_pin(GPIO_SET_LOW,LED_RED_PORT,LED_RED_PIN);
	gpio_set_pin(GPIO_SET_LOW,LED_ORANGE_PORT,LED_ORANGE_PIN);
	
	set_led_operation_work(0);
	printf("Automatic operation = %d\r\n", get_automatic_operation());
	printf("Program ready to work\r\n");
 	
	
	if(AUTOMATIC_VALVE_TEST == 0)
	{
		event_loop();
	}else 
	{
	
		init_cushions_state();
	}
	
	
	
	
	static volatile uint16_t pressure =0;

//	static uint8_t percent = 0;
	while (1)
	{	

		test_valve_cycle();
	}
}



void test_valve_cycle(void)
{
	
//Opening		
	changeValvePosition(MAIN_DEFLATE_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);
	
	changeValvePosition(CUSHION_1_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);

	changeValvePosition(CUSHION_2_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);

	changeValvePosition(CUSHION_3_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);

	changeValvePosition(CUSHION_4_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);

	
//Closing	
	changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);
	
	changeValvePosition(CUSHION_1_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);

	changeValvePosition(CUSHION_2_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);

	changeValvePosition(CUSHION_3_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);

	changeValvePosition(CUSHION_4_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_VALVE_SWITCH);
	
}


void init_cushions_state(void)
{
	set_led_operation_work(1);
	changeValvePosition(MAIN_DEFLATE_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_1_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_2_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_3_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_4_VALVE, etOpening);			
	HAL_Delay(TIME_BETWEEN_SWITCH);
	
	HAL_Delay(TIME_WHEN_ALL_CUSHIONS_OPEN);

	*get_current_cushion() = 0;
	
	set_led_operation_work(0);
/*	
	changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_1_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_2_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_3_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_SWITCH);

	changeValvePosition(CUSHION_4_VALVE, etClosing);			
	HAL_Delay(TIME_BETWEEN_SWITCH);
*/
}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0);

  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}


#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif


