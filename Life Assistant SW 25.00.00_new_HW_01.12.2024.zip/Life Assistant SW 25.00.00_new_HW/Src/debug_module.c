#include "include_all_headers.h"


TaskHandle DebugTaskhandlerId;
void gpioTask (void* op);

void DebugInitTask(void)
{
	DebugTaskhandlerId = add_task(&DebugTask);
	exec_task(DebugTaskhandlerId, 50, 1, (void*) NULL);					
}

void DebugTask (void* op)
{

		
	
}

