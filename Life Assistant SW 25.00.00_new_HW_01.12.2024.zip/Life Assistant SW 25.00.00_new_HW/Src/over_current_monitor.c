#include "include_all_headers.h"

#define VALVE_OVER_CURRENT_THRESHOLD 5000
#define PUMP_OVER_CURRENT_THRESHOLD  5000


TaskHandle OverCurrentTaskID;
//static A2dValue CurrentPressure;


//init current monitor task
void InitOverCurrentMonitorTask(void)
{	
	
  OverCurrentTaskID = add_task(&OverCurrentMonitorTask);
	exec_task(OverCurrentTaskID, 50, 1, (void*) NULL);
	
}


void OverCurrentMonitorTask(void *op)
{
#if 0
		CurrentPressure = *GetA2dResStruct(ANALOG_INPUT_2_CH_9, 10);	
		if(CurrentPressure.milliVoltValue > VALVE_OVER_CURRENT_THRESHOLD)
		{
			ResetAllValves();
			PumpStop();

			//**  Deflate the current cuashion an 
			StateMachineChangeState(etOpenValveToDeflation);
			exec_task(MainControllerTaskID, 20, 1, (void*) NULL);


			//update error status
			mainControllerInfo.deviceState.errorStatus = etOverCurrentError;
		}	
#endif		
}

