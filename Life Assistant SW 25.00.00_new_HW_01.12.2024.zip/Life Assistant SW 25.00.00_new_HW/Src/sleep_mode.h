#ifndef __ISLEEP_MODE_H
#define __ISLEEP_MODE_H

void InitSleepModeTask(void);
void SleepModeTask(void *op);
void SetPowerStopMode(void);
void ScheduleSleepModeTask(void);


#endif


