#include "include_all_headers.h"


static TimeStamp LastValveStartWorkTime;


TaskHandle StopValveTaskTaskID;
static TaskHandle FinalDeflateTaskTaskID;
TaskHandle CloseAllValvsTaskId;

void brake_all_valves(MotorState dir);
void finish_pwm_state(uint8_t valve, MotorState dir);
//static ValveState valveStates[5] = {etValveStateUnknown, etValveStateUnknown, etValveStateUnknown, etValveStateUnknown, etValveStateUnknown};

static  uint8_t valve_ready = 0;
static  uint8_t valve_pwm_c_r 	= 0;
static  uint8_t valve_pwm_c_l 	= 0;



uint8_t *get_valve_pwm_c_r(void)
{
	return &valve_pwm_c_r;
}

uint8_t *get_valve_pwm_c_l(void)
{
	return &valve_pwm_c_l;
}


TaskHandle *GetFinalDeflateTaskTaskID(void)
{
	return &FinalDeflateTaskTaskID;
}

//init final deflate all cushion task
void InitFinalDeflateTaskTask(void)
{	
	FinalDeflateTaskTaskID = add_task(&FinalDeflateTask);
}



//init close all valves task
void InitCloseAllValvsTask(void)
{	
  CloseAllValvsTaskId = add_task(&CloseAllValvsTask);
	//exec_task(CloseAllValvsTaskId, 50, 0, (void*) NULL);
}


void inflate_cushion(uint8_t cushion)
{
		/*
	
	if(deflation valve opened)
	{
		close deflation valve()
	}
	
	if(cushion n valve closed)
	open cushion n valve()
	
	start pump()
	*/
	
}

void deflate_cushion(uint8_t cushion)
{
		/*
	
	if(deflation valve closed)
	{
		open deflation valve()
	}
	
	if(cushion n valve closed)
	open cushion n valve()
	
	start pump()
	*/
	
}

void error_procedure(uint8_t err_code)
{
	/*
	reset all valves gpio
	stop the pump
	print error
	save error to flash
	
	if (critical error)
	{
		lock future use
	}else
	{
		do nothing
	}
	*/
	
	
}

void FinalDeflateTask(void *op)
{
	
	static uint8_t CurrentCushion = 0;
	static TimeStamp StepStartTime;
	static MotorState OperationStep = etOpening;
	
	if(OperationStep == etOpening)
	{
		switch(CurrentCushion)
		{

			case CUSHION_1_VALVE:
			{
				StepStartTime = *UtilitiesGetSystemClock();
				
				changeValvePosition(CUSHION_1_VALVE,etOpening);
				OperationStep = etOpening;
				CurrentCushion++;
			}
			break;
			
			case CUSHION_2_VALVE:
			{
				if(UtilitiesCheckTimeout(&StepStartTime,VALVE_TOTAL_CLOSING_TIME) && *Get_valve_ready_flag() == 1)
				{
					StepStartTime = *UtilitiesGetSystemClock();
					
					
					changeValvePosition(CUSHION_2_VALVE,etOpening);
					OperationStep = etOpening;
					CurrentCushion++;
				}
			}
			break;
			
			case CUSHION_3_VALVE:
			{
				if(UtilitiesCheckTimeout(&StepStartTime,VALVE_TOTAL_CLOSING_TIME) && *Get_valve_ready_flag() == 1)
				{
					StepStartTime = *UtilitiesGetSystemClock();
					
					
					changeValvePosition(CUSHION_3_VALVE,etOpening);
					OperationStep = etOpening;
					CurrentCushion++;
				}		
			}
			break;
			
			case CUSHION_4_VALVE:
			{
				if(UtilitiesCheckTimeout(&StepStartTime,VALVE_TOTAL_CLOSING_TIME) && *Get_valve_ready_flag() == 1)
				{
					StepStartTime = *UtilitiesGetSystemClock();
					
					changeValvePosition(CUSHION_4_VALVE,etOpening);
					OperationStep = etOpening;
					CurrentCushion++;
				}		
			}
			break;
			
			case MAIN_DEFLATE_VALVE:
			{
				if(UtilitiesCheckTimeout(&StepStartTime,VALVE_TOTAL_CLOSING_TIME) && *Get_valve_ready_flag() == 1)
				{
					StepStartTime = *UtilitiesGetSystemClock();
								
					changeValvePosition(MAIN_DEFLATE_VALVE,etOpening);
					OperationStep = etClosing;
					CurrentCushion = CUSHION_1_VALVE;
				}		
			}
			break;			
		}	
	}
	
	else	if(OperationStep == etClosing)
	{
		
		cancel_task(FinalDeflateTaskTaskID);
		OperationStep = etOpening;
		CurrentCushion = CUSHION_1_VALVE;
		mainControllerInfo.deviceState.finalDeflateAllCushionInProccess = false;
		mainControllerInfo.deviceState.currentCushion = 0;
		mainControllerInfo.deviceState.allCushionEmpty = true;

		return;
	}
}


void CloseAllValvsTask(void *op)
{
	
	changeValvePosition(CUSHION_1_VALVE,etClosing);
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	ResetAllValves();
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	
	changeValvePosition(CUSHION_2_VALVE,etClosing);
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	ResetAllValves();
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	
	changeValvePosition(CUSHION_3_VALVE,etClosing);
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	ResetAllValves();
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	
	changeValvePosition(CUSHION_4_VALVE,etClosing);
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	ResetAllValves();
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	
	changeValvePosition(MAIN_DEFLATE_VALVE,etClosing);
	HAL_Delay(VALVE_TOTAL_OPENING_TIME);
	ResetAllValves();
		
}
//init stop valve task
void InitStopValveTask(void)
{
		
	StopValveTaskTaskID = add_task(&StopValve);
		
}




uint8_t *Get_valve_ready_flag(void)
{
	return &valve_ready;
}

uint8_t is_valve_ready(void)
{
	return valve_ready;
}



void changeValvePosition(uint8_t valve,MotorState dir)
{
	
	printf("Valve NO %d is %s.\r\n", valve , dir == etClosing? "closing": "opening");
	

	gpio_set_pin(GPIO_SET_HI, ENABLE_5V_PORT, ENABLE_5V_PIN);
	
	//ensure that all gpio are low
	ResetAllValves();
	

	if(CheckGpioBeforToggle(valve,dir))
	{
			
			switch(valve)
				{
					case CUSHION_1_VALVE :
						if(dir == etOpening)
						{
							 getLoggStructPtr()->valve1Cnt++;
							//gpio_set_pin(GPIO_SET_HI,VALVE_L_C_OUTPUT_PORT,VALVE_L_C_OUTPUT_PIN);							
							PwmSetValvetDutiCycle(PWM_VALVE_OPEN_START_POWER,VALVE_L_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_L_1_OUTPUT_PORT,VALVE_L_1_OUTPUT_PIN);		
						}
						else if(dir == etClosing)
						{
							//gpio_set_pin(GPIO_SET_HI,VALVE_R_C_OUTPUT_PORT,VALVE_R_C_OUTPUT_PIN);
							PwmSetValvetDutiCycle(PWM_VALVE_CLOSE_START_POWER,VALVE_R_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_R_1_OUTPUT_PORT,VALVE_R_1_OUTPUT_PIN);			
						}
					break;

					case CUSHION_2_VALVE :
						if(dir == etOpening)
						{
							getLoggStructPtr()->valve2Cnt++;
							//gpio_set_pin(GPIO_SET_HI,VALVE_L_C_OUTPUT_PORT,VALVE_L_C_OUTPUT_PIN);							
							PwmSetValvetDutiCycle(PWM_VALVE_OPEN_START_POWER,VALVE_L_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_L_2_OUTPUT_PORT,VALVE_L_2_OUTPUT_PIN);
						}
						else 
						{
							//gpio_set_pin(GPIO_SET_HI,VALVE_R_C_OUTPUT_PORT,VALVE_R_C_OUTPUT_PIN);
							PwmSetValvetDutiCycle(PWM_VALVE_CLOSE_START_POWER,VALVE_R_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_R_2_OUTPUT_PORT,VALVE_R_2_OUTPUT_PIN);							
						}
					break;
						
					case CUSHION_3_VALVE :
						if(dir == etOpening)
						{
							getLoggStructPtr()->valve4Cnt++;
							//gpio_set_pin(GPIO_SET_HI,VALVE_L_C_OUTPUT_PORT,VALVE_L_C_OUTPUT_PIN);							
							PwmSetValvetDutiCycle(PWM_VALVE_OPEN_START_POWER,VALVE_L_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_L_3_OUTPUT_PORT,VALVE_L_3_OUTPUT_PIN);
						}
						else if(dir == etClosing)
						{
							//gpio_set_pin(GPIO_SET_HI,VALVE_R_C_OUTPUT_PORT,VALVE_R_C_OUTPUT_PIN);
							PwmSetValvetDutiCycle(PWM_VALVE_CLOSE_START_POWER,VALVE_R_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_R_3_OUTPUT_PORT,VALVE_R_3_OUTPUT_PIN);			
						}
					break;
						
					case CUSHION_4_VALVE :
						if(dir == etOpening)
						{getLoggStructPtr()->valve3Cnt++;
							//gpio_set_pin(GPIO_SET_HI,VALVE_L_C_OUTPUT_PORT,VALVE_L_C_OUTPUT_PIN);							
							PwmSetValvetDutiCycle(PWM_VALVE_OPEN_START_POWER,VALVE_L_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_L_4_OUTPUT_PORT,VALVE_L_4_OUTPUT_PIN);
						}else if(dir == etClosing)
						{
							//gpio_set_pin(GPIO_SET_HI,VALVE_R_C_OUTPUT_PORT,VALVE_R_C_OUTPUT_PIN);
							PwmSetValvetDutiCycle(PWM_VALVE_CLOSE_START_POWER,VALVE_R_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_R_4_OUTPUT_PORT,VALVE_R_4_OUTPUT_PIN);			
						}
					break;	
						
					case MAIN_DEFLATE_VALVE :
						if(dir == etOpening)
						{
							getLoggStructPtr()->valve5Cnt++;
							//gpio_set_pin(GPIO_SET_HI,VALVE_L_C_OUTPUT_PORT,VALVE_L_C_OUTPUT_PIN);							
							PwmSetValvetDutiCycle(PWM_VALVE_OPEN_START_POWER,VALVE_L_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_L_5_OUTPUT_PORT,VALVE_L_5_OUTPUT_PIN);
							
						}else if(dir == etClosing)
						{
							//gpio_set_pin(GPIO_SET_HI,VALVE_R_C_OUTPUT_PORT,VALVE_R_C_OUTPUT_PIN);
							PwmSetValvetDutiCycle(PWM_VALVE_CLOSE_START_POWER,VALVE_R_C_OUTPUT_PIN);
							gpio_set_pin(GPIO_SET_HI,VALVE_R_5_OUTPUT_PORT,VALVE_R_5_OUTPUT_PIN);			
							
						}
					break;			
						
					//invalid parameter
					default:
						return;
				}
					
				// delay to lower the power of the valve				
				if(dir == etOpening)
				{
					HAL_Delay(OPENING_TIME_BEFORE_BRAKE);
					
					brake_all_valves(dir);
					
					finish_pwm_state(valve, dir);
					
					PwmSetValvetDutiCycle(OPENING_PWM_PERCENT, VALVE_L_C_OUTPUT_PIN);
					
					HAL_Delay(OPENING_TIME_PWM_BEFORE_STOP);

				}
				else if(dir == etClosing)
				{
					HAL_Delay(CLOSING_TIME_BEFORE_BRAKE);	

					brake_all_valves(dir);
					
					finish_pwm_state(valve, dir);
					
					PwmSetValvetDutiCycle(CLOSING_PWM_PERCENT, VALVE_R_C_OUTPUT_PIN);

					HAL_Delay(CLOSING_TIME_PWM_BEFORE_STOP);
				
				}
		
				ResetAllValves();
				
//				HAL_Delay(50);
				printf("Valve NO %d is %s.\r\n", valve , dir == etClosing? "closed": "open");
			
		}
	
		getLoggStructPtr()->valveState[valve - 1] = dir == etClosing ? VALVE_CLOSED : VALVE_OPEN;
		
		gpio_set_pin(GPIO_SET_LOW, ENABLE_5V_PORT, ENABLE_5V_PIN);
		
		saveDataToFlash();
}

void finish_pwm_state(uint8_t valve, MotorState dir)
{
	switch(valve)
				{
					case CUSHION_1_VALVE :
						if(dir == etOpening)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_L_1_OUTPUT_PORT,VALVE_L_1_OUTPUT_PIN);		
						}
						else if(dir == etClosing)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_R_1_OUTPUT_PORT,VALVE_R_1_OUTPUT_PIN);			
						}
					break;

					case CUSHION_2_VALVE :
						if(dir == etOpening)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_L_2_OUTPUT_PORT,VALVE_L_2_OUTPUT_PIN);
						}
						else 
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_R_2_OUTPUT_PORT,VALVE_R_2_OUTPUT_PIN);							
						}
					break;
						
					case CUSHION_3_VALVE :
						if(dir == etOpening)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_L_3_OUTPUT_PORT,VALVE_L_3_OUTPUT_PIN);
						}
						else if(dir == etClosing)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_R_3_OUTPUT_PORT,VALVE_R_3_OUTPUT_PIN);			
						}
					break;
						
					case CUSHION_4_VALVE :
						if(dir == etOpening)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_L_4_OUTPUT_PORT,VALVE_L_4_OUTPUT_PIN);
						}else if(dir == etClosing)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_R_4_OUTPUT_PORT,VALVE_R_4_OUTPUT_PIN);			
						}
					break;	
						
					case MAIN_DEFLATE_VALVE :
						if(dir == etOpening)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_L_5_OUTPUT_PORT,VALVE_L_5_OUTPUT_PIN);
							
						}else if(dir == etClosing)
						{
							gpio_set_pin(GPIO_SET_HI,VALVE_R_5_OUTPUT_PORT,VALVE_R_5_OUTPUT_PIN);			
							
						}
					break;			
						
					//invalid parameter
					default:
						return;
				}
}

void brake_all_valves(MotorState dir)
{

					//Brake
			if(dir == etOpening)
			{	
				PwmSetValvetDutiCycle(100,VALVE_R_C_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_L_1_OUTPUT_PORT,VALVE_L_1_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_L_2_OUTPUT_PORT,VALVE_L_2_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_L_3_OUTPUT_PORT,VALVE_L_3_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_L_4_OUTPUT_PORT,VALVE_L_4_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_L_5_OUTPUT_PORT,VALVE_L_5_OUTPUT_PIN);

				HAL_Delay(OPENING_TIME_BRAKE);
			}else
			{
								
				PwmSetValvetDutiCycle(100,VALVE_L_C_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_R_1_OUTPUT_PORT,VALVE_R_1_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_R_2_OUTPUT_PORT,VALVE_R_2_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_R_3_OUTPUT_PORT,VALVE_R_3_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_R_4_OUTPUT_PORT,VALVE_R_4_OUTPUT_PIN);
				gpio_set_pin(GPIO_SET_HI,VALVE_R_5_OUTPUT_PORT,VALVE_R_5_OUTPUT_PIN);
				
				HAL_Delay(CLOSING_TIME_BRAKE);
			}
				

				ResetAllValves();

	
}

void OpenValve(void * time)
{
	
//	int param = (int)((uint8_t *)time + 8);
	ResetAllValves();	 	
	
	gpio_set_pin(GPIO_SET_TOGGLE,VALVE_L_3_OUTPUT_PORT,VALVE_L_3_OUTPUT_PIN);
	
}


void StopValve(void * op)
{
	ResetAllValves();
	mainControllerInfo.deviceState.Cushions[mainControllerInfo.deviceState.currentCushion].motorState = etDontWork;
}

void ResetAllValves(void)
{
	gpio_set_pin(GPIO_SET_LOW,VALVE_L_1_OUTPUT_PORT,VALVE_L_1_OUTPUT_PIN);
	gpio_set_pin(GPIO_SET_LOW,VALVE_R_1_OUTPUT_PORT,VALVE_R_1_OUTPUT_PIN);
	
	gpio_set_pin(GPIO_SET_LOW,VALVE_L_2_OUTPUT_PORT,VALVE_L_2_OUTPUT_PIN);
	gpio_set_pin(GPIO_SET_LOW,VALVE_R_2_OUTPUT_PORT,VALVE_R_2_OUTPUT_PIN);

	gpio_set_pin(GPIO_SET_LOW,VALVE_L_3_OUTPUT_PORT,VALVE_L_3_OUTPUT_PIN);
	gpio_set_pin(GPIO_SET_LOW,VALVE_R_3_OUTPUT_PORT,VALVE_R_3_OUTPUT_PIN);

	gpio_set_pin(GPIO_SET_LOW,VALVE_L_4_OUTPUT_PORT,VALVE_L_4_OUTPUT_PIN);
	gpio_set_pin(GPIO_SET_LOW,VALVE_R_4_OUTPUT_PORT,VALVE_R_4_OUTPUT_PIN);

	gpio_set_pin(GPIO_SET_LOW,VALVE_L_5_OUTPUT_PORT,VALVE_L_5_OUTPUT_PIN);
	gpio_set_pin(GPIO_SET_LOW,VALVE_R_5_OUTPUT_PORT,VALVE_R_5_OUTPUT_PIN);

	PwmSetValvetDutiCycle(0,VALVE_L_C_OUTPUT_PIN);
	PwmSetValvetDutiCycle(0,VALVE_R_C_OUTPUT_PIN);
						
	
	valve_ready = 1;
		
}

bool CheckGpioBeforToggle(uint8_t valve,MotorState dir)
{
	bool status = true;
	switch(valve)
		{
			case CUSHION_1_VALVE :
			{
				if(dir == etOpening)
				{
						if(*get_valve_pwm_c_r() == 1  ||
							 HAL_GPIO_ReadPin(VALVE_R_1_OUTPUT_PORT , VALVE_R_1_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}
				}
				else
				{
						if(*get_valve_pwm_c_l()  == 1    ||
							 HAL_GPIO_ReadPin(VALVE_L_1_OUTPUT_PORT , VALVE_L_1_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}
				}	
			}
			break;
			
			case CUSHION_2_VALVE :
			{
				if(dir == etOpening)
				{
						if(*get_valve_pwm_c_r()  == 1   ||
							 HAL_GPIO_ReadPin(VALVE_R_2_OUTPUT_PORT , VALVE_R_2_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}						
				}
				else
				{
						if(*get_valve_pwm_c_l()  == 1  ||
							 HAL_GPIO_ReadPin(VALVE_L_2_OUTPUT_PORT , VALVE_L_2_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}						
				}	
			}
			break;

			case CUSHION_3_VALVE :
			{
				if(dir == etOpening)
				{
						if(*get_valve_pwm_c_r()  == 1    ||
							 HAL_GPIO_ReadPin(VALVE_R_3_OUTPUT_PORT , VALVE_R_3_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}					
				}
				else
				{
						if(*get_valve_pwm_c_l()  == 1  ||
							 HAL_GPIO_ReadPin(VALVE_L_3_OUTPUT_PORT , VALVE_L_3_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}					
				}	
			}
			break;

			case CUSHION_4_VALVE :
			{
				if(dir == etOpening)
				{
						if(*get_valve_pwm_c_r()  == 1   ||
							 HAL_GPIO_ReadPin(VALVE_R_4_OUTPUT_PORT , VALVE_R_4_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}					
				}
				else
				{
						if(*get_valve_pwm_c_l()  == 1  ||
							 HAL_GPIO_ReadPin(VALVE_L_4_OUTPUT_PORT , VALVE_L_4_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}					
				}
			}
			break;

			case MAIN_DEFLATE_VALVE :
			{
				if(dir == etOpening)
				{
						if(*get_valve_pwm_c_r()  == 1   ||
							 HAL_GPIO_ReadPin(VALVE_R_5_OUTPUT_PORT , VALVE_R_5_OUTPUT_PIN)	!= GPIO_PIN_RESET
							)
							{
								printf("Short Error FET\r\n");
								status = false;
							}					
				}
				else
				{
						if(*get_valve_pwm_c_l()  == 1  ||
							 HAL_GPIO_ReadPin(VALVE_L_5_OUTPUT_PORT , VALVE_L_5_OUTPUT_PIN)	!= GPIO_PIN_RESET )
							{
								printf("Short Error FET\r\n");
								status = false;
							}					
				}
			}
			break;			
	}

	return status;
}

