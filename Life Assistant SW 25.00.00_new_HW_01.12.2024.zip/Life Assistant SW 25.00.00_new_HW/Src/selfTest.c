///////////////////////////////////////////////////////////////////////////////
// Source file selfTest.c
//
// Author:   Zoosmanovskiy Lev.
// email:    lev@Z-tech.co.il
// Copyright 11.2021, Zoosmanovskiy Lev.
// Communication protocol
///////////////////////////////////////////////////////////////////////////////

#include "selfTest.h"
#include "SerialTask.h"
#include "protocol.h"

#define MIN_PRESSURE_DIF_ATM_REF 100
#define MIN_PRESSURE_DIF_VALVES 50
#define MIN_PRESSURE_DIF_PUMP 200

#define TEST_TIME_BETWEEN_CLOSE 10
#define TEST_TIME_EXT_VALVE  250
#define TEST_TIME_VALVES  350
#define TEST_TIME_PUMP   300

#define REFERENCE_PRESSURE_mb ((float)(0.25))


static uint8_t _inTest = 0;
static TestStatus_s testStat;
char printBuff[128];

void testCloseAllValves(void);
void testPrintStr(char* str);
int testAnalyzeResult(void);


uint8_t isInTest(void)
{
	return _inTest;
}


int testWaitForStart(void)
{
	static uint32_t prevSend = 0;
	static uint32_t prevCheck = 0;
	
	testPrintStr("\r\n Test jig detected! \r\n Waiting for test to start\r\n");
	
	while(1)
	{
				
		if(prevCheck + 2 < HAL_GetTick())
		{
			prevCheck = HAL_GetTick();
			SerialTask(0);
		}
		
		if(prevSend + 5000 < HAL_GetTick())
		{
			prevSend = HAL_GetTick();
			//testStat.curPressure = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);
			//printf("Current pressure: %d \r\n" ,testStat.curPressure);
		}			
	}
}

int testSaveRef(uint16_t ref)
{

	flash_erase( FLASH_ADD + FLASH_PRESS_REF, 0);
	flash_write( FLASH_PRESS_REF, (uint8_t*)&ref,2);

return 0;	
}
	
int testStart(void)
{
	uint16_t refSample, openSample;
	_inTest = 1;	
	
//	testPrintStr("Starting test...\r\n\n");
//	ProtocolSendMessage(DevTypePC, OpcodeTestResult, (uint8_t*)&testStat, sizeof(testStat));
//	return 0;
	testPrintStr("Sensor test\r\n");
		//Close all valves
		testCloseAllValves();
	//Open Deflate valve for atmosphere pressure sample
	changeValvePosition(MAIN_DEFLATE_VALVE, etOpening);
	//Ensure the external valve is closed
	EXT_VALVE_OFF();
	//Wait for pressure stabilization
	HAL_Delay(TEST_TIME_EXT_VALVE);
	//Sample the atm. pressure
	testStat.atmPressure = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);
	
	sprintf(printBuff, "Atm. pressure: [%d] \r\n" ,testStat.atmPressure);
	testPrintStr(printBuff);
	
	//Close the deflate valve
	changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);
	//Open the external valve for sampling the refference pressure
	EXT_VALVE_ON();
	//Satb. wait
	HAL_Delay(TEST_TIME_EXT_VALVE);
	//Ref. presure sample
	testStat.refPressure = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);
	//Close the ext. valve
	EXT_VALVE_OFF();
	//Satb. wait
	HAL_Delay(TEST_TIME_EXT_VALVE*2);
	
	sprintf(printBuff, "Ref. pressure: [%d] \r\n" ,testStat.refPressure);
	testPrintStr(printBuff);
	
		
	//See if pressure was changed enough
//	if(testStat.refPressure > testStat.atmPressure)
//	{
		testStat.pressDiff = testStat.refPressure - testStat.atmPressure;
		testStat.a2dCoeff = REFERENCE_PRESSURE_mb / ((float)testStat.refPressure - testStat.atmPressure);
		
		testSaveRef(testStat.pressDiff);
		
		sprintf(printBuff, "Pressure Diff:  [%d] \r\n" ,testStat.pressDiff);
		testPrintStr(printBuff);	
		
		/*
		This state approving following hardware:
		LED1 TP7
		Input 1 (PB1)
		Input 2 (PB2)
		Ext valve output - (LED2, TP8)
		Deflate valve
		Pressure sensor
		*/
//	}
//	else	if(testStat.pressDiff <= MIN_PRESSURE_DIF_ATM_REF)
//	{
//		sprintf(printBuff, "\r\n TEST FAIL\r\n DIF [%d ]< THR [%d]\r\n", testStat.pressDiff, MIN_PRESSURE_DIF_ATM_REF);
//		testPrintStr(printBuff);
//		testPrintStr("Test fail\r\n");
//	}
	
	
	testPrintStr("Valves Test\r\n");
	for(uint8_t i = 1; i<=5; i++)
	{
		//Open the external valve for sampling the refference pressure
		EXT_VALVE_ON();
		//Satb. wait
		HAL_Delay(TEST_TIME_VALVES);
		//Get ref sample
		refSample = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);
		//Open valve
		changeValvePosition(i, etOpening);
		//Satb. wait
		HAL_Delay(TEST_TIME_VALVES);
		//Get open sample
		openSample = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);

		//Close the ext. valve
		EXT_VALVE_OFF();
		//Open valve
		changeValvePosition(i, etClosing);
			
		testStat.valveDiff[i-1] = refSample - openSample;
		sprintf(printBuff, "Valve:[%d] pressure diff: [%d]\r\n",i, refSample - openSample);
		testPrintStr(printBuff);
		
	}
	
	
	
	//Open deflate valve
	changeValvePosition(MAIN_DEFLATE_VALVE, etOpening);
	//Satb. wait
	HAL_Delay(TEST_TIME_PUMP);
	//Get atm sample
	refSample = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);
	
		//Clse valve
	changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);
	
	//Start pump
	PumpStart();
	//Satb. wait
	HAL_Delay(TEST_TIME_PUMP);
	//Get pump sample
	openSample = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);

	//Stop pump
	PumpStop();
	

		testStat.pumpDiff = openSample - refSample;
	sprintf(printBuff, "Pump pressure: [%d]\r\n", testStat.pumpDiff);
	testPrintStr(printBuff);

	testStat.result = (testAnalyzeResult() == 0);
//Send test result
	ProtocolSendMessage(DevTypePC, OpcodeTestResult, (uint8_t*)&testStat, sizeof(testStat));
	_inTest = 0;	
	
	return 0;
}


//Analyze results
int testAnalyzeResult(void)
{
	if(testStat.pressDiff < MIN_PRESSURE_DIF_ATM_REF)
		return -1;
	if(testStat.pumpDiff < MIN_PRESSURE_DIF_PUMP)
		return -1;
	
		
	for(uint8_t i = 1; i<5; i++)
	{
		if(testStat.valveDiff[i - 1] < MIN_PRESSURE_DIF_VALVES)
		return -1;
	}
	
	return 0;
}
	
void testPrintStr(char* str)
{
	ProtocolSendMessage(DevTypePC, OpcodeInfoMsg, (uint8_t*)str, strlen(str));
}

int testCancel(void)
{
	_inTest = 0;
	
	return 0;
}

void testCloseAllValves(void)
{
	changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);			
	HAL_Delay(TEST_TIME_BETWEEN_CLOSE);
	
	changeValvePosition(CUSHION_1_VALVE, etClosing);			
	HAL_Delay(TEST_TIME_BETWEEN_CLOSE);

	changeValvePosition(CUSHION_2_VALVE, etClosing);			
	HAL_Delay(TEST_TIME_BETWEEN_CLOSE);

	changeValvePosition(CUSHION_3_VALVE, etClosing);			
	HAL_Delay(TEST_TIME_BETWEEN_CLOSE);

	changeValvePosition(CUSHION_4_VALVE, etClosing);
	HAL_Delay(TEST_TIME_BETWEEN_CLOSE);
}

int testSetGpioMode(TestGpioState_e st)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	switch (st)
	{
		case _GPIO_STATE_TEST:
			GPIO_InitStruct.Mode = GPIO_MODE_INPUT;	
			GPIO_InitStruct.Pin  = TEST_DETECT_IN_1_PIN;
			GPIO_InitStruct.Pull = GPIO_PULLUP;	
			HAL_GPIO_Init(TEST_DETECT_IN_1_PORT, &GPIO_InitStruct);
			
			GPIO_InitStruct.Mode = GPIO_MODE_INPUT;	
			GPIO_InitStruct.Pin  = TEST_DETECT_IN_2_PIN;
			GPIO_InitStruct.Pull = GPIO_PULLUP;	
			HAL_GPIO_Init(TEST_DETECT_IN_2_PORT, &GPIO_InitStruct);
		
		
			GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;	
			GPIO_InitStruct.Pin  = TEST_DETECT_OUT_PIN;
			GPIO_InitStruct.Pull = GPIO_PULLUP;	
			HAL_GPIO_Init(TEST_DETECT_OUT_PORT, &GPIO_InitStruct);
		

			break;
		case _GPIO_STATE_WORK:
			// config 2 input buttons
			GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;	
			GPIO_InitStruct.Pin  = USER_INFLATE_BUTTON_PIN;
			GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
			HAL_GPIO_Init(USER_BUTTONS_INPUT_PORT, &GPIO_InitStruct);

			GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;	
			GPIO_InitStruct.Pin  = USER_DEFLATE_BUTTON_PIN;
			GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
			HAL_GPIO_Init(USER_BUTTONS_INPUT_PORT, &GPIO_InitStruct);
		
			_inTest = 0;
			break;
	}
	
	
	
	
	return 0;
}
//Detect if in JIG
int testIsInJig(void)
{
	GPIO_PinState in1, in2, out;
	
	testSetGpioMode(_GPIO_STATE_TEST);
	
	for(int i = 0; i < 16; i++)
	{
				
		if((i % 2) == 0)
		{ 
			out = GPIO_PIN_SET; 
		} else  
		{
			out = GPIO_PIN_RESET;
		}
		
		//Toggle LED1 (PORTB10)
		HAL_GPIO_WritePin(TEST_DETECT_OUT_PORT, TEST_DETECT_OUT_PIN, out);
		HAL_Delay(10);
		//Read input PB1(PORTB4) and PB2 (PORTB3)
		in1 = HAL_GPIO_ReadPin(TEST_DETECT_IN_1_PORT, TEST_DETECT_IN_1_PIN);
		in2 = HAL_GPIO_ReadPin(TEST_DETECT_IN_2_PORT, TEST_DETECT_IN_2_PIN);
		
		
		
		if(out == GPIO_PIN_SET)
		{			
			if( in1 == GPIO_PIN_RESET && in2 == GPIO_PIN_RESET)
			{
				continue;
			}else
			{
				testSetGpioMode(_GPIO_STATE_WORK);
				return 0;
			}
		}
			else if(out == GPIO_PIN_RESET)
		{			
			if( in1 == GPIO_PIN_SET && in2 == GPIO_PIN_SET)
			{
				continue;
			}else
			{
				testSetGpioMode(_GPIO_STATE_WORK);
				return 0;
			}
		}
	}
	
		return 1;
}
