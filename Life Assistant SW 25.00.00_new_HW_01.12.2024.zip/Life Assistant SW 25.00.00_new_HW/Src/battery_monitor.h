#ifndef __BATTERY_MONITOR_H
#define __BATTERY_MONITOR_H

#define BATTERY_THRESHOLD 80

A2dValue *GetCurrentBatterytLevel(void);
void BatteryMonotorTask(void *op);
void InitBatteryMonitorTask(void);

#endif


