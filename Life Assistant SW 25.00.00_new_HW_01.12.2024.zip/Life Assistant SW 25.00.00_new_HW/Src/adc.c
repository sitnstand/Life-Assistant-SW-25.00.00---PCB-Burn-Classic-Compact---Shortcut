#include "include_all_headers.h"


a2dInfo A2dInfo;
void adc_calibrate(void);

void	AdcInit(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;

__ADC1_CLK_ENABLE();

	
	GPIO_InitStruct.Pin = ANALOG_INPUT_BATTERY;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;
	HAL_GPIO_Init(ANALOG_PORT_INPUT_WEIGHT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = ANALOG_INPUT_PIN_2;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(ANALOG_PORT_INPUT_2, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = ANALOG_INPUT_PRESSURE_SENS;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(ANALOG_PORT_INPUT_PRESSURE_SENS, &GPIO_InitStruct);

	adc_calibrate();
  adc_enable();	
	
	HAL_Delay(100);
	uint16_t press_offset = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10);
	
	set_pressure_offset(  press_offset );
	
	//printf("\r\n pressure offset: %d", press_offset);
	
	// calibrate the pressure(0) value. from this pressure value need go up constant degree's to know that the pressure is in the target p.  
	//A2dInfo.pressureSensorP0 = *GetA2dResStruct(ANALOG_INPUT_PRESSURE_CH, 10);
}

void adc_calibrate(void)
{

    uint32_t start_time = HAL_GetTick();
    //read internal calibration

        if ((ADC1->CR & ADC_CR_ADEN) != 0) 
        {
            ADC1->CR &= (uint32_t)(~ADC_CR_ADEN); 
        }

        ADC1->CR |= ADC_CR_ADCAL; 
        
        while ((ADC1->CR & ADC_CR_ADCAL) != 0) 
        {
            if(HAL_GetTick() > (start_time + ADC_TIMEOUT ))
            {
                return;
            }
        }
}


void adc_disable(void)
{
    uint32_t start_time = HAL_GetTick();
    
    if ((ADC1->CR & ADC_CR_ADEN) == 0) 
    {
        return;
    }
        
    if ((ADC1->CR & ADC_CR_ADSTART) != 0) 
    {
        ADC1->CR |= ADC_CR_ADSTP; 
    }
    
    while ((ADC1->CR & ADC_CR_ADSTART) != 0) 
    {
    //    ADC1->CR |= ADC_CR_ADSTP; 
        if(HAL_GetTick() > (start_time + ADC_TIMEOUT ))
        {
            return;
        }
    }
    
    while ((ADC1->CR & ADC_CR_ADSTP) != 0) 
    {
        ADC1->CR |= ADC_CR_ADSTP; 
        if(HAL_GetTick() > (start_time + ADC_TIMEOUT ))
        {
            return;
        }
    }
    
    ADC1->CR |= ADC_CR_ADDIS;
    
    while ((ADC1->CR & ADC_CR_ADEN) != 0) 
    {
        if(HAL_GetTick() > (start_time + ADC_TIMEOUT ))
        {
            return;
        }
    }    

}


uint16_t adc_get_value(uint32_t channel, uint8_t oversample) 
{
	
	uint32_t start_time = HAL_GetTick();
	uint32_t val = 0;

	//adc_enable();
	if((ADC1->ISR & ADC_ISR_ADRDY) == 0)
	{
		ADC1->CR |= ADC_CR_ADEN; 
	}
	
	ADC1->SMPR |= ADC_SMPR_SMP_0 | ADC_SMPR_SMP_1 | ADC_SMPR_SMP_2; /* (3) */
	ADC->CCR |= ADC_CCR_VREFEN; /* (4) */
			
	ADC1->CHSELR = channel;
				
	//OVR clear
	ADC1->ISR |= (1<<4);

	int i = 0;	
	
	for( i=0; i < oversample; i++)
	{
		ADC1->CR |= ADC_CR_ADSTART; /* Start the ADC conversion */

		while ((ADC1->ISR & ADC_ISR_EOC) == 0 )
			//|| (ADC1->ISR & ADC_ISR_EOSEQ) == 0 || (ADC1->ISR & ADC_ISR_EOSMP) == 0) /* Wait end of conversion */
		{
			
			if(HAL_GetTick() > (start_time + ADC_TIMEOUT ))
			{
				return 0;
			}
		}
			val += ADC1->DR; /* Store the ADC conversion result */
	}
	
	return val/i;
}

void adc_enable(void)
{
	
	uint32_t start_time = HAL_GetTick();
	
	ADC1->CR |= ADC_CR_ADEN; /* (1) */

	ADC1->ISR |= (1<<4);
	
	while ((ADC1->ISR & ADC_ISR_ADRDY) == 0) /* (2) */
	{
		ADC1->CR |= ADC_CR_ADEN; 
		if(HAL_GetTick() > (start_time + ADC_TIMEOUT ))
		{
			return;
		}
	}
}


A2dValue *GetA2dResStruct(uint32_t channel, uint8_t oversample)
{		
	A2dInfo.lastA2dSample.A2dChannel = channel;
 	A2dInfo.lastA2dSample.digitalValue = adc_get_value(channel,oversample);
	A2dInfo.lastA2dSample.milliVoltValue = (uint16_t)(((float)VREF_VOLTAGE/MAX_A2D_VALUE) * A2dInfo.lastA2dSample.digitalValue);
	A2dInfo.lastA2dSample.miliVoltPercent	=  ((float)100/VREF_VOLTAGE) * A2dInfo.lastA2dSample.milliVoltValue;
	
	return & A2dInfo.lastA2dSample;
}

