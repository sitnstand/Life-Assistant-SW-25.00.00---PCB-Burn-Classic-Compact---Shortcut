///////////////////////////////////////////////////////////////////////////////
// Source file protocol.c
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2021, Zoosmanovskiy Lev.
// Communication protocol
///////////////////////////////////////////////////////////////////////////////

#include "protocol.h"



#define WHO_AM_I DevTypeDUT

void UartTxBuffer(uint8_t* buff, uint16_t len);


static Message msg;
static volatile uint32_t protocolTimeOutCnt = 0;



/**************************************************
* Function name	: ProtocolSendMessage
* Returns	:	
* Arg		: 
* Created by	: Lev Zoosmanovskiy
* Date created	: 20/01/2020
* Description	: Builds and sends protocol message
* Notes		: 
**************************************************/
ErrorCode ProtocolSendMessage(DevType dst, Opcode opcode, uint8_t* data, uint16_t len)
  {
  uint16_t dataLen = len;
  uint16_t msgSize = dataLen + PROTOCOL_HEADER_SIZE;
  
  ErrorCode err = etErrorCodeSuccess;
  //Fill the header
  msg.preamble = MESSAGE_PREAMBLE;
  msg.opcode = opcode;
  msg.len = dataLen;
  msg.dest = dst;
  msg.source = WHO_AM_I;
  
  //Copy data
  if (msgSize && dataLen <= MAX_DATA_SIZE)
    {
    memcpy(msg.data, data, dataLen);
    }
  else
    {
    return etErrorCodeWrongSize;
    }
  //Put the Checksum
  msg.crc = 0;
  msg.crc = ProtocolCalcCrc((uint8_t*)&msg, msgSize); 
  //Send message
  
  

  switch (dst)
    {
    case DevTypePC: 
      HAL_UART_Transmit(&huart1, (uint8_t*) &msg, msgSize, msgSize * 1);
      break;
    default:
      break;
    }   
  
  return err;
  }

/**************************************************
* Function name	: ProtocolCalcCrc
* Returns	:	
* Arg		: 
* Created by	: Lev Zoosmanovskiy
* Date created	: 20/01/2020
* Description	: Calculates check sum for the protocol messages
* Notes		: //-- CRC-16-CCITT (poly 0x1021) --//
**************************************************/
uint16_t ProtocolCalcCrc(const uint8_t* buff ,uint16_t len)
  {
  uint8_t byte;
  uint16_t crc = 0xFFFF;
  
  while (len--)
    {
    byte = crc >> 8 ^ *buff++;
    byte ^= byte>>4;
    crc = (crc << 8) ^ ((uint16_t)(byte << 12)) ^ ((uint16_t)(byte <<5)) ^ ((uint16_t)byte);
    }
  return crc;
  }

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

volatile static MsgState ProtocolParseState = etMsgStateWaitingForPreamble;
static volatile uint32_t startTime;
  static uint8_t ProtocolParseSubstate = 0;

void ProtocolCheckTimeout(void)
  {
  //Timeout 
  if (ProtocolParseState != etMsgStateWaitingForPreamble)
    {
    if (startTime + USART_PROTOCOL_TIMEOUT < _GetTime())
      {
      //ProtocolSendMessage(OpcodeMessageTimeout, NULL,0);  //send Nack message  
      ProtocolParseState = etMsgStateWaitingForPreamble;
      ProtocolParseSubstate = 0;
      protocolTimeOutCnt++;
      }
    }
  }  

/**************************************************
* Function name	: ProtocolParseMsg
* Returns	:	
* Arg		: 
* Created by	: Lev Zoosmanovskiy
* Date created	: 20/01/2020
* Description	: Protocol message collecting state machine
* Notes		: //Preamle -> length -> opcode -> crc -> data...
**************************************************/

int ProtocolParseMsg(Message* rxMessage, uint8_t byte)
  {
  static int dataIndex = 0;
  
  char rxByte = byte;
  
  switch (ProtocolParseState)
    {
    //Waiting for message preamble (2 bytes)
    case etMsgStateWaitingForPreamble:
      {
      uint16_t preamble = MESSAGE_PREAMBLE;
      uint8_t  preamble_a = (uint8_t)(preamble & 0xFF);
      uint8_t  preamble_b = (uint8_t)(preamble >> 8 & 0x00FF);
      
      startTime = _GetTime();
      //First byte of preamle
      if (ProtocolParseSubstate == 0)
        {
        if (rxByte == preamble_a)
          {
          rxMessage->preamble = rxByte;
          ProtocolParseSubstate++;
          }
        }
      //Second byte of preamle
      else if (ProtocolParseSubstate == 1)
        {
        if (rxByte == preamble_b)
          {
          rxMessage->preamble |= (rxByte << 8 & 0xFF00);
          ProtocolParseState = etMsgStateReadingLength;
          dataIndex = 0;
          ProtocolParseSubstate = 0;
          }
        else
          {
          ProtocolParseSubstate = 0;
          }
        }
      }  
      break;
    
    //Reading length (2 bytes)
    case etMsgStateReadingLength:
      {
      //First byte
      if (ProtocolParseSubstate == 0)
        {  
        ProtocolParseSubstate++;
        rxMessage->len = rxByte;
        }
      //Second byte
      else if (ProtocolParseSubstate == 1)
        {
        ProtocolParseSubstate = 0;
        rxMessage->len |= (rxByte << 8 & 0xFF00);
        //Valid length?
        if (rxMessage->len <= MAX_DATA_SIZE) 
          {
          ProtocolParseState = etMsgStateReadingOpcode; //Next state
          }
        else
          {
          ProtocolParseState = etMsgStateWaitingForPreamble; //Invalid data size
          }
        }
      }
      break;
    
    //Reading opcode
    case etMsgStateReadingOpcode:
      rxMessage->opcode = (Opcode)rxByte;
      ProtocolParseState = etMsgStateReadingSource; //Next state
      break;
      
      //Reading source
    case etMsgStateReadingSource :
      rxMessage->source = (DevType)rxByte;
      ProtocolParseState = etMsgStateReadingDest; //Next state        
      break;
      
    case etMsgStateReadingDest:
      //Reading destination
      ProtocolParseState = etMsgStateReadingCrc; //Next state
      rxMessage->dest = (DevType)rxByte;
      break;
      
      //Reading CRC (2 bytes)
    case etMsgStateReadingCrc:
      //First byte
      if (ProtocolParseSubstate == 0)
        {  
        rxMessage->crc = rxByte;
        ProtocolParseSubstate++;
        }
      //Second byte
      else if (ProtocolParseSubstate == 1)
        {
        rxMessage->crc |= (rxByte << 8);
        if (rxMessage->len == 0)
          {
          ProtocolParseState = etMsgStateMessageReady;//Next state
          }
        else 
          {
          ProtocolParseState = eMsgStatetReadingData; //Next state
          }
        ProtocolParseSubstate = 0;
        }
      break;
    
    //Collecting data
    case eMsgStatetReadingData:
    //Overflow protection
    if (dataIndex <= MAX_DATA_SIZE)
      {
      //Collect the data
      rxMessage->data[dataIndex] = rxByte;
      dataIndex++;
      }
    else
      {
      ProtocolParseState = etMsgStateWaitingForPreamble;
      }
    //End of the data 
    if (dataIndex >= rxMessage->len)
      {
      dataIndex = 0;
      ProtocolParseState = etMsgStateMessageReady;
      }
    break;
			
		default:
			break;
    }
    
		
  if (ProtocolParseState == etMsgStateMessageReady)
    {
    ProtocolParseState = etMsgStateWaitingForPreamble;
    return etMsgStateMessageReady;
    }
  
  return ProtocolParseState;
  }



/**************************************************
* Function name	: ProtocolMessageValidateCrc
* Returns	:	
* Arg		: 
* Created by	: Lev Zoosmanovskiy
* Date created	: 20/01/2020
* Description	: Validates the checksum
* Notes		: 
**************************************************/
uint8_t ProtocolMessageValidateCrc(Message* pMsg, uint16_t val)
  {  
  pMsg->crc = 0;
  pMsg->crc = ProtocolCalcCrc((const uint8_t*) pMsg ,pMsg->len + PROTOCOL_HEADER_SIZE);
  return (val == pMsg->crc);
  }
