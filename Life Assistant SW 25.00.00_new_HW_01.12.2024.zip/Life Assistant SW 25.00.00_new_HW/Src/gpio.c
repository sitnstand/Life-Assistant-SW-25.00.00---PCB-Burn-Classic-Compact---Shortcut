#include "include_all_headers.h"

static gpio_listener listeners[5];
static int listenersNum = 0;
GpioInfo gpioInfo;

void inflate_button(void);
void deflate_button(void);



void GpioInit(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;

	/* GPIO Ports Clock Enable */
	__GPIOA_CLK_ENABLE();
	__GPIOB_CLK_ENABLE();
	__GPIOC_CLK_ENABLE();	
	__GPIOF_CLK_ENABLE();


		// Battery voltage sensing enable
	GPIO_InitStruct.Pin  = BATTERY_CHECK_EN_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(BATTERY_CHECK_EN_PORT, &GPIO_InitStruct);
	
		// 5 Volts for valves enable
	GPIO_InitStruct.Pin  = ENABLE_5V_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(ENABLE_5V_PORT, &GPIO_InitStruct);
	
		// Sensor op-amp enable
	GPIO_InitStruct.Pin  = ENABLE_SENSOR_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(ENABLE_SENSOR_PORT, &GPIO_InitStruct);
	
	
	// config valves/motors gpio's 
	GPIO_InitStruct.Pin  = VALVE_L_1_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_L_1_OUTPUT_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin  = VALVE_R_1_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_R_1_OUTPUT_PORT, &GPIO_InitStruct);
	
	
	
	GPIO_InitStruct.Pin  = VALVE_L_2_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_L_2_OUTPUT_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin  = VALVE_R_2_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_R_2_OUTPUT_PORT, &GPIO_InitStruct);	
	
	

	GPIO_InitStruct.Pin  = VALVE_L_3_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_L_3_OUTPUT_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin  = VALVE_R_3_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_R_3_OUTPUT_PORT, &GPIO_InitStruct);	
	
	
	
	GPIO_InitStruct.Pin  = VALVE_L_4_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_L_4_OUTPUT_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin  = VALVE_R_4_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_R_4_OUTPUT_PORT, &GPIO_InitStruct);	
	
	GPIO_InitStruct.Pin  = VALVE_L_5_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_L_5_OUTPUT_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin  = VALVE_R_5_OUTPUT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_R_5_OUTPUT_PORT, &GPIO_InitStruct);	
	
	// config led pin's
	GPIO_InitStruct.Pin  = LED_RED_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(LED_RED_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin  = LED_GREEN_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(LED_GREEN_PORT, &GPIO_InitStruct);	
	
	GPIO_InitStruct.Pin  = LED_ORANGE_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(LED_ORANGE_PORT, &GPIO_InitStruct);	
	

	GPIO_InitStruct.Pin  = VALVE_REGULATOR_ENABLE_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(VALVE_REGULATOR_ENABLE_PORT, &GPIO_InitStruct);	
	
	
// config pump gpio
//	GPIO_InitStruct.Pin  = PUMP_OUTPUT_PIN;
//	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
//	HAL_GPIO_Init(PUMP_OUTPUT_PORT, &GPIO_InitStruct);
	
	

	// config 2 input buttons
	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;	
	GPIO_InitStruct.Pin  = USER_INFLATE_BUTTON_PIN;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(USER_BUTTONS_INPUT_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;	
	GPIO_InitStruct.Pin  = USER_DEFLATE_BUTTON_PIN;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;	
	HAL_GPIO_Init(USER_BUTTONS_INPUT_PORT, &GPIO_InitStruct);
	
	
	//config IT to the 2 buttons
  /* (1) Enable the peripheral clock of GPIOA */ 
  /* (2) Select Port A for pin 0 external interrupt by writing 0000 in EXTI0 (reset value)*/
  /* (3) Configure the corresponding mask bit in the EXTI_IMR register */
  /* (4) Configure the Trigger Selection bits of the Interrupt line on rising edge*/
  /* (5) Configure the Trigger Selection bits of the Interrupt line on falling edge*/
  //RCC->AHBENR |= RCC_AHBENR_GPIOCEN; /* (1) */
  //SYSCFG->EXTICR[0] &= (uint16_t)~SYSCFG_EXTICR2_EXTI4_PB | SYSCFG_EXTICR1_EXTI3_PB; /* (2) */
  //EXTI->IMR  = 0x0018; /* (3) */ // bit 4 & bit 5
  //EXTI->RTSR = 0x0018; /* (4) */ // bit 4 & bit 5
  //EXTI->FTSR = 0x0018; /* (5) */ // bit 4 & bit 5
	//EXTI->RTSR = 0x0018; /* (5) */ // bit 4 & bit 5
  
  /* Configure NVIC for External Interrupt */
  /* (6) Enable Interrupt on EXTI0_1 */
  /* (7) Set priority for EXTI0_1 */
  NVIC_EnableIRQ(EXTI4_15_IRQn); /* (6) */
  NVIC_SetPriority(EXTI4_15_IRQn,0); /* (7) */
	
	NVIC_EnableIRQ(EXTI2_3_IRQn); /* (6) */
  NVIC_SetPriority(EXTI2_3_IRQn,0); /* (7) */

	ResetAllValves();
	gpioInfo.UserButtonClickt = etNonButton;
	gpio_set_pin(GPIO_SET_LOW , PUMP_OUTPUT_PORT,PUMP_OUTPUT_PIN);
}


TaskHandle GPIO_Task_Handler;
void gpioTask (void* op);

void start_gpio_listener(void)
	{
		exec_task(GPIO_Task_Handler, 1, 1, (void*) NULL);
	}
	
void stop_gpio_listener(void)
	{
		cancel_task(GPIO_Task_Handler);					
	}
	
void gpioInitTask(void)
{
	GPIO_Task_Handler = add_task(&gpioTask);
	exec_task(GPIO_Task_Handler, 1, 1, (void*) NULL);					
}


//	static uint16_t pressure_val_adc;
//	static uint16_t pressure_val_mv;
	

#define MAIN_CONTROLLER_TASK_PERIOD 10

void testModeMonitor(void);

void gpioTask (void* op)
{		
	static uint32_t inflatePressed = 0;
	static uint32_t deflatePressed = 0;
	static uint8_t inflate = 1;
	static uint8_t inDeflate = 0;
	static uint8_t inInflate = 0;
	
	if(getLoggStructPtr()->errorFlag == 1)
	{
		if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_DEFLATE_BUTTON_PIN)  == GPIO_PIN_SET )
		{
			inflatePressed++;
		}else
		{
			inflatePressed = 0;
		}
		
		
		if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_INFLATE_BUTTON_PIN)  == GPIO_PIN_SET )
		{
				deflatePressed ++;
		}else
		{
			inflatePressed = 0;
		}
		
		
		if(inflatePressed > TIME_TO_PRESS_FOR_RELEASE_FAILURE && inflatePressed > TIME_TO_PRESS_FOR_RELEASE_FAILURE)
		{
			getLoggStructPtr()->errorFlag = 0;
			getLoggStructPtr()->watchDogCnt = 0;
			*get_system_error() = 0;
			saveDataToFlash();
			gpio_set_pin(GPIO_SET_LOW,LED_RED_PORT,LED_RED_PIN);
			init_cushions_state();		
		}
		
		return;
	}
	else
	{
		testModeMonitor();
	}

	
	//Automatic operation case
	if(get_automatic_operation())
	{

		HAL_Delay(TIME_BETWEEN_INFLATE_DEFLATE_TEST_MODE);
		{
			if(inflate == 1)
			{
				ui_button_pressed(UI_BUTTON_INFLATE);
				
				inflate = 0;
			}else
			{
				ui_button_pressed(UI_BUTTON_DEFLATE);
				
				inflate = 1;
			}
		}

		//Manual operation case
	}else	if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_DEFLATE_BUTTON_PIN)  == GPIO_PIN_SET || HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_INFLATE_BUTTON_PIN)  == GPIO_PIN_SET )
	{
	
		//Deflate button
		if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_DEFLATE_BUTTON_PIN)  == GPIO_PIN_SET  && HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_INFLATE_BUTTON_PIN)  == GPIO_PIN_RESET)
		{
			
			if(!inDeflate)
			{
				inDeflate  = 1;
				ui_button_pressed(UI_BUTTON_DEFLATE);					
			}
			
		}else
		{
			inDeflate  = 0;
		}
		
		//Inflate button
		if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_INFLATE_BUTTON_PIN)  == GPIO_PIN_SET && HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_DEFLATE_BUTTON_PIN)  == GPIO_PIN_RESET)
		{
			if(!inInflate)
			{
				inInflate = 1;
				ui_button_pressed(UI_BUTTON_INFLATE);
				pumpInfo.pumpVolumePrecent = MIN_PUMP_VOLUME;
			}
		}
		else
		{
			inInflate = 0;
		}
			
		//entry to sleep(stop) mode
		ScheduleSleepModeTask();		
	}
	
	if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_DEFLATE_BUTTON_PIN)  == GPIO_PIN_RESET )
	{
		inDeflate  = 0;
	}
	
	if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_INFLATE_BUTTON_PIN)  == GPIO_PIN_RESET )
		{
			inInflate = 0;
		}
	
}


uint16_t infPress = 0, defPress = 0;
void test_valve_cycle(void);
void set_automatic_operation(uint8_t op);
void init_cushions_state(void);

//Monitors the buttons and enters automatic mode
//After a long (TIME_TO_PRESS_FOR_TEST_MODE) hold of both buttons
void testModeMonitor(void)
{
		//Release from fail mode
	if(getLoggStructPtr()->errorFlag == 0)
	{
		if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_DEFLATE_BUTTON_PIN)  == GPIO_PIN_SET )
		{
			infPress++;
		}else
		{
			infPress = 0;
		}
		
		
		if(HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_INFLATE_BUTTON_PIN)  == GPIO_PIN_SET )
		{
				defPress++;
		}else
		{
			defPress = 0;
		}
		
		
		if(defPress > TIME_TO_PRESS_FOR_TEST_MODE && infPress > TIME_TO_PRESS_FOR_TEST_MODE)
		{
		//	while(1)
			{
			 //test_valve_cycle();
				init_cushions_state();
				set_automatic_operation(1);
			}
			//Set test mode
		}
	}
	
}
bool DriversGetGpioPinState(GPIO_TypeDef  *GPIOx ,uint16_t PINx)
{
  if(HAL_GPIO_ReadPin(GPIOx,PINx))
	{
		return true;
	}
  return false;
}

void add_gpio_listener(gpio_listener listener){

	listeners[listenersNum] = listener;
	listenersNum++;
	
}

void handle_gpio_intr(int gpio_num){
	
	for(int i=0; i < listenersNum; i++){
	
		listeners[i](gpio_num);
		
	}
	clear_intr(gpio_num);
}

void clear_intr(int gpio_num){

	EXTI->PR |= gpio_num;
	
}


void handleButtonEvent(int gpio_num){

	
	if ((EXTI->PR & USER_INFLATE_BUTTON_PIN) != 0  )		
  {
		EXTI->PR |= 0x0010;
	}
	
  if ((EXTI->PR & USER_DEFLATE_BUTTON_PIN) != 0  )		
  {
		EXTI->PR |= 0x0008;
	}

}

void DriversSetGpioPinState(GPIO_TypeDef  *GPIOx ,uint16_t PINx, GPIO_PinState value)
{
	HAL_GPIO_WritePin(GPIOx, PINx, value);
}


void gpio_set_pin(GPIO_STATE state, GPIO_TypeDef* port,uint16_t pin)
{    
        switch (state)
        {    
            case GPIO_SET_HI:
                port->BSRR |= pin;
            break;
            
            case GPIO_SET_LOW:
                port->BRR |= pin;
            break;      
            case GPIO_SET_TOGGLE:
                port->ODR ^= pin;
					 break;
            
        default:
            break;
    }
}

