/**
  ******************************************************************************
  * File Name          : usart.c
  * Date               : 28/05/2015 01:43:47
  * Description        : Aplication to driver layer
  ******************************************************************************
  */
#include "include_all_headers.h"
#include "circ_buff.h"
#include "protocol.h"
#include "SerialTask.h"

UartInfoType uartInfo;


#define PROTOCOL_CIRC_BUFF_SIZE 64
tCircularBuffer* ProtocolCircBuffer;


TaskHandle RxCommandTaskID;


//TODO make static or remove
UART_HandleTypeDef huart1;


tCircularBuffer* usartGetCircBuff(void)
{
	return ProtocolCircBuffer;
}

UART_HandleTypeDef * UartGetHuart1Struct(void)
{
  return &huart1;
}

DMA_HandleTypeDef  hdma_usart2_rx;


uint8_t uart_receive(uint8_t uart, uint8_t *data, uint8_t len){
	
	UART_HandleTypeDef *handle;
	
	if(uart == 1){
		handle = &huart1;
	}
	
	return HAL_UART_Receive_IT(handle, data, len) == HAL_OK; 
	
}



void uartPutData(UART_HandleTypeDef *huart, uint8_t *data, uint32_t length)
{
			HAL_UART_Transmit(huart, data, length, length * 1);
}

void uartPutString(uint8_t uart, uint8_t *ch)
{

	uint16_t length = strlen( (char*) ch );
	volatile uint8_t stat=0;
		stat = HAL_UART_Transmit(&huart1, ch, length, length * 2);		
}


/* USART init function */
void InitUsart(void)
{
//	GPIO_InitTypeDef GPIO_InitStruct;


  huart1.Instance = USART1;
  huart1.Init.BaudRate = PROTOCOL_UART_SPEED;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONEBIT_SAMPLING_DISABLED ;
  
	huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	HAL_UART_Init(&huart1);
	
 
	ProtocolCircBuffer = CreateCircularBuffer(PROTOCOL_CIRC_BUFF_SIZE);
  
	if (!ProtocolCircBuffer)
  {//Can't allocate memory
    while (1);//can't create buffer
  }
	else
	{
	// Start Interrupt
		HAL_UART_Receive_IT(&huart1, GetWritePtr(ProtocolCircBuffer),1);
	 //USART1->CR1 |= USART_CR1_RXNEIE;
		SerialInit();
	}
}


void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(huart->Instance==USART1)
  {
    __USART1_CLK_ENABLE();
  
    /**USART1 GPIO Configuration    
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX 
    */
	GPIO_InitStruct.Pin = USART1_TX_PIN | USART1_RX_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
	HAL_GPIO_Init(USART1_PORT, &GPIO_InitStruct);
	

  /* System interrupt init*/
    HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{

  if(huart->Instance==USART1)
  {
    /* Peripheral clock disable */
    __USART1_CLK_DISABLE();
  
    /**USART1 GPIO Configuration    
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX 
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

    /* Peripheral interrupt DeInit*/
    HAL_NVIC_DisableIRQ(USART1_IRQn);

  }
  else if(huart->Instance==USART2)
  {
    /* Peripheral clock disable */
    __USART2_CLK_DISABLE();
  
    /**USART2 GPIO Configuration    
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX 
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_2|GPIO_PIN_3);
    /* Peripheral interrupt DeInit*/
    HAL_NVIC_DisableIRQ(USART2_IRQn);
		
  }

}

static uint8_t rxChar;
void USART1_IRQHandler(void)
{	

		rxChar = (uint8_t)USART1->RDR;
	
			
			FillBuffer(ProtocolCircBuffer, &rxChar, 1);
			HAL_UART_Receive_IT(&huart1, &rxChar,1);

		USART1->ICR |= USART1->ISR;
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){

	if(huart == &huart1)
	{
		HAL_UART_Receive_IT(&huart1, GetWritePtr(ProtocolCircBuffer),1);
	}
	
}


uint8_t buff[128];
uint8_t currSize;

int fputc(int ch, FILE *f)
{
	buff[currSize++] = (uint8_t)ch;
	
  if(ch == '\n'){
		
		HAL_UART_Transmit(&huart1, buff, currSize, 100);
	
		currSize = 0;
	}
	
  return(ch);
}


void uart_disable_interrupts()
{
	HAL_NVIC_DisableIRQ(USART1_IRQn);
	HAL_NVIC_DisableIRQ(USART2_IRQn);
	
}

void uart_enable_interrupts(){
	HAL_NVIC_EnableIRQ(USART1_IRQn);
	HAL_NVIC_EnableIRQ(USART2_IRQn);
	
}
