#ifndef __PUMP_CONTROLLER_H
#define __PUMP_CONTROLLER_H



typedef enum
{
	etPumpStoped = 0,
	etPumpWork,
}PumpState;

typedef  struct
{
	uint8_t   currentSpeed;
	PumpState currentPumpState;
  TimeStamp StartPumpWorkTime;
	int       pumpVolumePrecent;
} PumpInfo;


extern PumpInfo pumpInfo;



void PumpStart(void);
void StopPumpTaskTask(void *op);
void PumpSet(uint8_t volume);
void InitStopPumpTaskTask(void);
void pump_start(uint8_t caushion);
void PumpStop(void);
void InitSoftStartPumpTask(void);
void SoftStartPumpTask(void *op);
void SoftStartPump(void);

#endif

