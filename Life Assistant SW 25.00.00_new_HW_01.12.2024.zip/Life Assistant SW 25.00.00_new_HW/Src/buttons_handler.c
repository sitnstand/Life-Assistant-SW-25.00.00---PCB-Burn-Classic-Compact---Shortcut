
/**
  ******************************************************************************
  * File Name          : buttons_handler.c
  * Date               : 11/05/2016 17:18:46
  * Description        : User buttons handler
	* Author: Lev.
  ******************************************************************************
  
  ******************************************************************************
  */
	
#include "include_all_headers.h"

static uint8_t inflate_button_pressed = 0;
static uint8_t deflate_button_pressed = 0;

/*

	if(inflate button pressed)
	{
		inflate_button_pressed = 1;
		inflate button handler();
	}else
	{
		inflate_button_pressed = 0;
	}

	if(deflate button pressed)
	{
		deflate_button_pressed = 1;
		deflate button handler();
	}else
	{
		deflate_button_pressed = 0;
	}
*/

void inflate_button(void)
{
	/*
		if(current cushio < 4)
	{
		inflate next cushion()
	}
	*/
}

void deflate_button(void)
{
	/*
		if(current cushio > 1)
	{
		deflate next cushion()
	}
	*/
}