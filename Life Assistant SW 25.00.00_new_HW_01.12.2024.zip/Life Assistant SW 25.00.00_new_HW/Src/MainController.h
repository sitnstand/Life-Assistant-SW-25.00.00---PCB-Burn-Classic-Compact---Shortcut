#ifndef _MAIN_CONTROLLER_H_
#define _MAIN_CONTROLLER_H_

#define CUSHION_AMOUNT 4
#define LOWER_CUSHION 0

#define CUSHION_1_VALVE 		1
#define CUSHION_2_VALVE 		2
#define CUSHION_3_VALVE 		4
#define CUSHION_4_VALVE 		3
#define MAIN_DEFLATE_VALVE  5


typedef void (*StateFunction)(void);


typedef enum
{
	etDontWork = 0,
	etClosing,  
	etOpening,
	
}MotorState;

typedef enum
{
	etValveStateOpen = 0,
	etValveStateClosed,
	etValveStateUnknown
}ValveState;

typedef enum
{
	etNoOperation = 0,
	etInflating,
	etDeflating
	
}OperationType;


typedef enum
{
	etUserClickEvent = 0,
	etCheckStillButtonPressed,	
	etCheckWeight,	
	etOpenValveToDeflation,	
	etDeflation,	
	etOpenValveToInflation,	
	etStartInflation,
	etWaitToInflateCushion,
	etCloseValve,	
	etCheckTimout,
	etWaitToDeflateCushion,
	etFinalDeflateAllCushion,
	etTimeoutEvent,
	etWeightError,
	etFinish,
	etSleep,
	etLastState
}State;

typedef struct
{
	ValveState valveState;
	MotorState motorState;
	bool CushionInflated;
	
}Cushion;


typedef enum
{
	etSuccess = 0,
	etInflationTimoutError,
	etDeflationTimoutError,	
	etOverCurrentError
	
}ErrorState;

typedef struct
{
	uint8_t  description[40];
	StateFunction stateFunction;
	
}OperationState;

typedef enum
{
	etInflate = 0,
	etDeflate
	
}OparationType;


typedef enum
{
	etSubStateInit = 0,
	etSubStateRunning,
	etSubStateFinalize
}SubStateType;


typedef struct
{
	uint8_t       currentCushion;
	ErrorState    errorStatus;
	State         currentState;
	State         previusState;
	SubStateType  SubState;
  Cushion       Cushions[CUSHION_AMOUNT];
	TimeStamp     StartCurrentState;
	TimeStamp     StartDeflateState;
	bool          MainControllerTaskWork;
	OparationType LastOparation;
	bool 					allCushionEmpty;
	bool          finalDeflateAllCushionInProccess;
}DeviceState;

typedef struct
{
	int w0;
	int t1;
	int DeflateMaxTime;
	int InflateMaxTime;
}Configuration;


typedef struct
{
	Configuration deviceConfiguration;
	DeviceState   deviceState;
	bool  stateChangedEvent;
}MainControllerInfo;







extern MainControllerInfo mainControllerInfo;
extern TaskHandle MainControllerTaskID;
void InitMainControllerTask(void);
void MainControllerTask(void * ptr);
void StateMachineChangeState(State newState);
void InitStateMachine(void);
bool CheckWeightOnTheCushion(void);

#endif




