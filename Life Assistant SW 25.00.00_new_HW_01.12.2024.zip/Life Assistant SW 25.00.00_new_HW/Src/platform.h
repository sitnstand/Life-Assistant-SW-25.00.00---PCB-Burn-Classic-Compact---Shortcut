#ifndef _PLATFORM_H
#define _PLATFORM_H


//   ADC CONSTANTS
#define  ANALOG_INPUT_BATTERY                 GPIO_PIN_6
#define  ANALOG_INPUT_BATTERY_CH		          ADC_CHSELR_CHSEL6         //port b pin 1
#define  ANALOG_PORT_INPUT_WEIGHT             GPIOA
                                     
#define  ANALOG_INPUT_PIN_2                   GPIO_PIN_0
#define  ANALOG_INPUT_2_CH_9                  ADC_CHSELR_CHSEL8        	//port b pin 0
#define  ANALOG_PORT_INPUT_2                  GPIOB
                                     
#define  ANALOG_INPUT_PRESSURE_SENS           GPIO_PIN_7
#define  ANALOG_INPUT_PRESSURE_CH             ADC_CHSELR_CHSEL7         //port a pin 7
#define  ANALOG_PORT_INPUT_PRESSURE_SENS      GPIOA
                                     

// END ADC CONSTANTS



// GPIO CONSTANTS


#define  BATTERY_CHECK_EN_PIN         GPIO_PIN_9     
#define  BATTERY_CHECK_EN_PORT				GPIOB           

#define  ENABLE_5V_PIN         				GPIO_PIN_8
#define  ENABLE_5V_PORT								GPIOB          

#define  ENABLE_SENSOR_PIN       			GPIO_PIN_15
#define  ENABLE_SENSOR_PORT						GPIOB          

#define  VALVE_L_1_OUTPUT_PIN         GPIO_PIN_0      // ML1
#define  VALVE_L_1_OUTPUT_PORT        GPIOA           // MR1

#define  VALVE_R_1_OUTPUT_PIN         GPIO_PIN_1      // MR1
#define  VALVE_R_1_OUTPUT_PORT        GPIOA           // MR1

#define  VALVE_L_2_OUTPUT_PIN         GPIO_PIN_2      // ML2
#define  VALVE_L_2_OUTPUT_PORT        GPIOA           // ML2

#define  VALVE_R_2_OUTPUT_PIN         GPIO_PIN_3      // MR2
#define  VALVE_R_2_OUTPUT_PORT        GPIOA           // MR2

#define  VALVE_L_3_OUTPUT_PIN         GPIO_PIN_4      // ML3
#define  VALVE_L_3_OUTPUT_PORT        GPIOA           // ML3

#define  VALVE_R_3_OUTPUT_PIN         GPIO_PIN_5      // MR3
#define  VALVE_R_3_OUTPUT_PORT        GPIOA           // MR3


#define  VALVE_L_4_OUTPUT_PIN         GPIO_PIN_13  		// ML4
#define  VALVE_L_4_OUTPUT_PORT        GPIOB        		// ML4
		
#define  VALVE_R_4_OUTPUT_PIN         GPIO_PIN_12  		// MR4   
#define  VALVE_R_4_OUTPUT_PORT        GPIOB        		// MR4  

#define  VALVE_L_5_OUTPUT_PIN         GPIO_PIN_9      // ML5
#define  VALVE_L_5_OUTPUT_PORT        GPIOA           // ML5

#define  VALVE_R_5_OUTPUT_PIN         GPIO_PIN_8      // MR5
#define  VALVE_R_5_OUTPUT_PORT        GPIOA           // MR5

#define  VALVE_L_C_OUTPUT_PIN         GPIO_PIN_11     // MLC
#define  VALVE_L_C_OUTPUT_PORT        GPIOA           // MLC

#define  VALVE_R_C_OUTPUT_PIN         GPIO_PIN_10     // MRC  
#define  VALVE_R_C_OUTPUT_PORT        GPIOA           // MRC  

#define VALVE_REGULATOR_ENABLE_PIN		GPIO_PIN_12
#define VALVE_REGULATOR_ENABLE_PORT		GPIOA

#define  PUMP_OUTPUT_PIN              GPIO_PIN_14  		// PUMP  
#define  PUMP_OUTPUT_PORT             GPIOB        		// PUMP  

#define  USER_INFLATE_BUTTON_PIN      GPIO_PIN_4      // push button
#define  USER_INFLATE_BUTTON_PORT     GPIOB						// push button

#define  USER_DEFLATE_BUTTON_PIN      GPIO_PIN_3			// push button
#define  USER_BUTTONS_INPUT_PORT      GPIOB					// push button



		
#define  LED_RED_PIN      						GPIO_PIN_10    	// led 1
#define  LED_RED_PORT     						GPIOB						// led 1

#define  LED_GREEN_PIN      					GPIO_PIN_11			// led 2
#define  LED_GREEN_PORT       				GPIOB						// led 2

#define  LED_ORANGE_PIN      					GPIO_PIN_2			// led 2
#define  LED_ORANGE_PORT       				GPIOB						// led 2


//8 and 9 is Short 
#define  PWM_CH_1_OUTPUT_PIN         GPIO_PIN_8
#define  PWM_CH_2_OUTPUT_PIN         GPIO_PIN_9
//#define  PWM_CH_3_OUTPUT_PIN         GPIO_PIN_10
//#define  PWM_CH_4_OUTPUT_PIN         GPIO_PIN_11
#define  PWM_OUTPUT_PORT             GPIOB

// END GPIO CONSTANTS



// TIMER1 CONSTANTS

#define TIM1_FREQUENCY 8000000
#define TIMER1_FREQUENCY	1000 //Hz

#define  TIMER1_PRESCALER  0
#define  TIMER1_PERIOD  TIM1_FREQUENCY / TIMER1_FREQUENCY + 1
#define  TIMER1_REPETITION_COUNTER 10

// END TIMER1 CONSTANTS


// USART1 CONSTANTS

#define  USART1_TX_PIN   GPIO_PIN_6
#define  USART1_RX_PIN   GPIO_PIN_7
#define  USART1_PORT     GPIOB

// END USART1 CONSTANTS

#endif





