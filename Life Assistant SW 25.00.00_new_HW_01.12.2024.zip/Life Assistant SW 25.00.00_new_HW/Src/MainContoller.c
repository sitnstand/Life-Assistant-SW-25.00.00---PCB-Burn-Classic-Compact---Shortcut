#include "include_all_headers.h"

TaskHandle MainControllerTaskID;
MainControllerInfo mainControllerInfo;

void StateFuncUserClickEvent(void);            
void StateFuncCheckStillButtonPressed(void);   
void StateFuncCheckWeight(void);               
void StateFuncDeflation(void);                 
void StateFuncInflation(void);                 
void StateFuncCheckTimout(void);               
void StateFuncTimeoutEvent(void);              
void StateFuncWeightError(void);               
void StateFuncFinish(void);                    
void StateFuncSleep(void);                     
void StateFuncWaitToDeflateCushion(void);   
void StateFuncWaitToInflateCushion(void);
void StateFuncFinalDeflateAllCushion(void);



 //state machine states array.
static OperationState OperationStateTable[etLastState] = 
{
	[etUserClickEvent]                 = {"User button event"                						,  StateFuncUserClickEvent              },
	[etCheckStillButtonPressed]        = {"Button still pressed ?"        							,  StateFuncCheckStillButtonPressed     },
	[etCheckWeight]                    = {"Someone sit on the Cushion ?"      					,  StateFuncCheckWeight                 },

	[etDeflation]                      = {"Start deflate process"                       ,  StateFuncDeflation                   },
	[etStartInflation]                 = {"Start inflate process"                       ,  StateFuncInflation                   },
	[etWaitToInflateCushion]           = {"Waiting for inflate finish"      						,  StateFuncWaitToInflateCushion        },	
	[etCheckTimout]                    = {"Check inflate timout"                        ,  StateFuncCheckTimout                 },
	[etWaitToDeflateCushion]           = {"Wait to finish deflate current Cushion"      ,  StateFuncWaitToDeflateCushion        },	
	[etFinalDeflateAllCushion]         = {"Final deflate all cushion"                   ,  StateFuncFinalDeflateAllCushion      },	
	[etTimeoutEvent]                   = {"Timout trashold"                             ,  StateFuncTimeoutEvent                },
	[etWeightError]        						 = {"No one sits on the Cushion"                  ,  StateFuncWeightError                 },
	[etFinish]                         = {"End process"                                 ,  StateFuncFinish                      },
	[etSleep]                          = {"The system sleeping"                         ,  StateFuncSleep                       },
};




//init Main Controller task
void InitMainControllerTask(void)
{		
	MainControllerTaskID = add_task(&MainControllerTask);
	
	mainControllerInfo.deviceState.MainControllerTaskWork = false;
	mainControllerInfo.deviceState.LastOparation = etInflate;
}


void MainControllerTask(void * ptr)
{
	//ErrCode error = ErrSucssess;
		
	if(OperationStateTable[mainControllerInfo.deviceState.currentState].stateFunction != NULL )		
	{
		OperationStateTable[mainControllerInfo.deviceState.currentState].stateFunction();
	}
	
	if(mainControllerInfo.stateChangedEvent == true)
	{
		mainControllerInfo.stateChangedEvent = false;		
		printf(" **Stata change**   from   %s  ->   %s.\r\n",OperationStateTable[mainControllerInfo.deviceState.previusState].description,OperationStateTable[mainControllerInfo.deviceState.currentState].description);
	}
	
}

//Not in use now
void StateFuncUserClickEvent(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			if(gpioInfo.UserButtonClickt == etDeflateButton)
			{
				StateMachineChangeState(etCheckWeight);
			}
			else if(gpioInfo.UserButtonClickt == etInflateButton)
			{
				StateMachineChangeState(etStartInflation);			
			}
			else if(gpioInfo.UserButtonClickt == etNonButton)
			{
				StateMachineChangeState(etFinish);
			}				
		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}
//Not in use now
}


//Not in use now
void StateFuncCheckStillButtonPressed(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			if(gpioInfo.UserButtonClickt == etDeflateButton  )
			{
				if(DriversGetGpioPinState(USER_BUTTONS_INPUT_PORT ,USER_DEFLATE_BUTTON_PIN))
				{
					 StateMachineChangeState(etCheckWeight);
				}
				else
				{
					gpioInfo.UserButtonClickt = etNonButton;
					StateMachineChangeState(etUserClickEvent);
					cancel_task(MainControllerTaskID);
				}
			}
			else if(gpioInfo.UserButtonClickt == etInflateButton )
			{
				if(DriversGetGpioPinState(USER_BUTTONS_INPUT_PORT ,USER_INFLATE_BUTTON_PIN))
				{
				
				}
				else
				{
					 gpioInfo.UserButtonClickt = etNonButton;
					 StateMachineChangeState(etUserClickEvent);
					 cancel_task(MainControllerTaskID);
				}
			}
		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}
//Not in use now
}

//Always returning true, until develpoment of weight sensor
void StateFuncCheckWeight(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
				if(CheckWeightOnTheCushion() == true)
				{
					
				}
				else
					StateMachineChangeState(etFinish);
				
		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}

}

void StateFuncOpenValveToDeflation(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			changeValvePosition(MAIN_DEFLATE_VALVE,etOpening);			
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			//TODO -  check over current
			if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartCurrentState, VALVE_TOTAL_OPENING_TIME) && *Get_valve_ready_flag() == 1)
			{	
				mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
				changeValvePosition(mainControllerInfo.deviceState.currentCushion,etOpening);		
			  mainControllerInfo.deviceState.SubState++;				
			}			

		}
		break;
		case etSubStateFinalize:
		{
			//TODO -  check over current
			if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartCurrentState, VALVE_TOTAL_OPENING_TIME) && *Get_valve_ready_flag() == 1)
			{			
				mainControllerInfo.deviceState.StartDeflateState = *UtilitiesGetSystemClock();			
				StateMachineChangeState(etWaitToDeflateCushion);	
			}

		}
		break;
	}
}

void StateFuncWaitToDeflateCushion(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();	
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartDeflateState, TIME_TO_DEFLATION))
			{	
				changeValvePosition(mainControllerInfo.deviceState.currentCushion,etClosing);	

				if(mainControllerInfo.deviceState.currentCushion == LOWER_CUSHION)
				{
					mainControllerInfo.deviceState.allCushionEmpty  = true;
				}

			  mainControllerInfo.deviceState.SubState++;				
			}			

		}
		break;
		case etSubStateFinalize:
		{
			if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartCurrentState, MAX_TIME_VALVE_MOTOR_WORK)   && *Get_valve_ready_flag() == 1)
			{			
				//mainControllerInfo.deviceState.StartDeflateState = *UtilitiesGetSystemClock();	
				//changeValvePosition(MAIN_DEFLATE_VALVE,etClosing);	
				if(mainControllerInfo.deviceState.currentCushion > LOWER_CUSHION)
				{
					mainControllerInfo.deviceState.currentCushion--;
				  StateMachineChangeState(etFinish);						
				}
				else
				{
					StateMachineChangeState(etFinalDeflateAllCushion);	
				}
				
			  mainControllerInfo.deviceState.LastOparation = etDeflate;

			}

		}
		break;
	}
}


void StateFuncFinalDeflateAllCushion(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();	
			
			mainControllerInfo.deviceState.finalDeflateAllCushionInProccess = true;
			exec_task(*GetFinalDeflateTaskTaskID(), 5, 1, (void*) NULL);
				
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			if(!mainControllerInfo.deviceState.finalDeflateAllCushionInProccess  && *Get_valve_ready_flag() == 1)
			{			
					StateMachineChangeState(etFinish);
			}
			
		}
		break;
		case etSubStateFinalize:
		{

		}
		break;
	}
}


void StateFuncDeflation(void)
{
	
	//Don't check if all valves closed
	//If button not pressed -> close the main valve
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			 if( mainControllerInfo.deviceState.LastOparation == etInflate && mainControllerInfo.deviceState.allCushionEmpty  == false && mainControllerInfo.deviceState.currentCushion > LOWER_CUSHION)
			 {
					mainControllerInfo.deviceState.currentCushion--;	
					StateMachineChangeState(etCheckWeight);				 
			 }
			 else if(mainControllerInfo.deviceState.allCushionEmpty  == false)
			 {
			 		StateMachineChangeState(etCheckWeight);	
			 }
			 else
			 {
			 		StateMachineChangeState(etFinish);				 
			 }
	
		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}

}


void StateFuncInflation(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
				if(mainControllerInfo.deviceState.LastOparation == etDeflate  && mainControllerInfo.deviceState.allCushionEmpty == false)
				{
					mainControllerInfo.deviceState.currentCushion++;
				}
			  if(mainControllerInfo.deviceState.currentCushion < CUSHION_AMOUNT)
				{
					StateMachineChangeState(etOpenValveToInflation);	
				}
				else
				{
						StateMachineChangeState(etFinish);	
				}


		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}

}


void StateFuncWaitToInflateCushion(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();	
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			A2dValue CurrentPressure = *GetA2dResStruct(ANALOG_INPUT_PRESSURE_CH, 10);
			
			printf("pressureSensorP0 = %d, P0_ABSOLUTE_VALUE = %d, current pressure = %d. \r\n",A2dInfo.pressureSensorP0.digitalValue,P0_ABSOLUTE_VALUE, CurrentPressure.digitalValue - A2dInfo.pressureSensorP0.digitalValue);
		
			if(UtilitiesCheckTimeout(&pumpInfo.StartPumpWorkTime,DELAY_TO_START_SAMPLE_PRESSURE))
			{
				if((CurrentPressure.digitalValue - A2dInfo.pressureSensorP0.digitalValue > P0_ABSOLUTE_VALUE))
				{	
					if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartDeflateState, MIN_TIME_INFLATION))
					{
						changeValvePosition(mainControllerInfo.deviceState.currentCushion,etClosing);	
						mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();	
						
						mainControllerInfo.deviceState.allCushionEmpty  = false;
						
						mainControllerInfo.deviceState.SubState++;	

				
					}
					else
					{
						changeValvePosition(mainControllerInfo.deviceState.currentCushion,etClosing);	
						mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();	
						
						mainControllerInfo.deviceState.allCushionEmpty  = false;
						
						mainControllerInfo.deviceState.SubState++;	
				
						//mainControllerInfo.deviceState.errorStatus = etInflationTimoutError;			
					}
				
				}	
				
				else if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartDeflateState, MAX_TIME_INFLATION))
				{	
					changeValvePosition(mainControllerInfo.deviceState.currentCushion,etClosing);	
					mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();	
					
					mainControllerInfo.deviceState.allCushionEmpty  = false;
					
					mainControllerInfo.deviceState.SubState++;	

					//mainControllerInfo.deviceState.errorStatus = etInflationTimoutError;					
				}	
			}			

		}
		break;
		case etSubStateFinalize:
		{
			//TODO -  check over current
			if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartDeflateState, VALVE_TOTAL_OPENING_TIME)  && *Get_valve_ready_flag() == 1)
			{	
				//PumpStop();				
				
				//ResetAllValves();
			  mainControllerInfo.deviceState.currentCushion++;
				StateMachineChangeState(etFinish);	
			}
			mainControllerInfo.deviceState.LastOparation = etInflate;

		}
		break;
	}
}


void StateFuncFinish(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			//WriteRecordToFlash(0, (uint8_t*) &mainControllerInfo,sizeof(MainControllerInfo));
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{
			
			if(UtilitiesCheckTimeout(&mainControllerInfo.deviceState.StartCurrentState, TIME_BETWEEN_2_BUTTON_CLICK)  && *Get_valve_ready_flag() == 1)
			{	
				
				cancel_task(*GetSaveDataToFlasfTaskID());
				exec_task(*GetSaveDataToFlasfTaskID(), WAIT_TIME_TO_SAVE_DATA_AFTER_PROCESS, 0, (void*) NULL);	// save the date on flash after 1 minute 

				mainControllerInfo.deviceState.MainControllerTaskWork = false;
				cancel_task(MainControllerTaskID);
			}
		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}

}

void StateFuncWeightError(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{


		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}

}

void StateFuncSleep(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{


		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}

}

void StateFuncTimeoutEvent(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{


		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}
}

void StateFuncCheckTimout(void)
{
	switch (mainControllerInfo.deviceState.SubState)
	{
		case etSubStateInit:
		{
			mainControllerInfo.deviceState.StartCurrentState = *UtilitiesGetSystemClock();
			mainControllerInfo.deviceState.SubState++;
		}
		break;

		case etSubStateRunning:
		{


		}
		break;
		case etSubStateFinalize:
		{


		}
		break;
	}
}

void StateMachineChangeState(State newState)
{
		mainControllerInfo.deviceState.previusState = mainControllerInfo.deviceState.currentState;
	  mainControllerInfo.deviceState.currentState = newState;
	  mainControllerInfo.deviceState.SubState = etSubStateInit; 
	  mainControllerInfo.stateChangedEvent = true;

}

void InitStateMachine(void)
{	
	mainControllerInfo.deviceState.errorStatus = etSuccess;
	mainControllerInfo.stateChangedEvent = false;
	mainControllerInfo.deviceState.currentState = etUserClickEvent;	
	mainControllerInfo.deviceState.SubState = etSubStateInit;	
	mainControllerInfo.deviceState.MainControllerTaskWork = false;
	mainControllerInfo.deviceState.allCushionEmpty = true;
	
}



bool CheckWeightOnTheCushion(void)
{
	return true;
}
