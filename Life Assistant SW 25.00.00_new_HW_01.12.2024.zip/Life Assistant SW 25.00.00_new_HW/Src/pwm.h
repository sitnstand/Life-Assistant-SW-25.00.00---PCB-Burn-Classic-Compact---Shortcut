#ifndef __PWM_H
#define __PWM_H

#define PWM_MODULE_FREQUENCY 32000000


typedef struct
{

  uint8_t tim1_pwm_on;
	
}pwmInfo;


extern pwmInfo PwmInfo;
void PwmInit(void);
void pwm_stop(void);
void pwm_start(uint32_t channel, uint32_t freq,uint8_t duty_percent);



#define PWM_PIN_MODE_PWM	0
#define PWM_PIN_MODE_GPIO	1

void pwm_set_gpio(uint8_t mode);
//LEV

void init_pwm(void);
void pwm_set_frequency(uint32_t freq);
void pwm_start(uint32_t channel, uint32_t freq,uint8_t duty_percent);
void pwm_set_duty_cycle(uint8_t duty_percent);
void PwmSetValvetDutiCycle(uint8_t duty_percent, uint16_t valve);

#endif














