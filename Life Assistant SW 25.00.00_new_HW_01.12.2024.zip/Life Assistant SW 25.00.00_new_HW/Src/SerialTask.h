///////////////////////////////////////////////////////////////////////////////
// Source file SerialTask.h
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2021, Zoosmanovskiy Lev.
// Serial communication task header
///////////////////////////////////////////////////////////////////////////////

#ifndef __SERIAL_TASK_H_
#define __SERIAL_TASK_H_

#include <string.h>
#include "include_all_headers.h"

int SerialInit(void);
void SerialTask(void * ptr);
#endif
