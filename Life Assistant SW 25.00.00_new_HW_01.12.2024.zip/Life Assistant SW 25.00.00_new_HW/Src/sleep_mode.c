#include "include_all_headers.h"



TaskHandle SleepModeTaskID;



//init Main Controller task
void InitSleepModeTask(void)
{		
	SleepModeTaskID = add_task(&SleepModeTask);			
	ScheduleSleepModeTask();
}




void SleepModeTask(void *op)
{		
	SetPowerStopMode();
}

void SetPowerStopMode(void)
{		
	printf("Sleep mode\r\n");
	HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON,PWR_STOPENTRY_WFI);
}


void ScheduleSleepModeTask(void)
{
	cancel_task(SleepModeTaskID);
	//exec_task(SleepModeTaskID, TIME_BEFOR_SLEEP_MODE, 0, (void*) NULL);
}




