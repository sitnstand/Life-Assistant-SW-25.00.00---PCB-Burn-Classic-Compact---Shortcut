#ifndef __MAIN_STATE_MACHINE
#define __MAIN_STATE_MACHINE


#define UI_BUTTON_INFLATE 1
#define UI_BUTTON_DEFLATE 2
#include "stm32f0xx_hal.h"
#include "stm32f0xx.h"
#include "stm32f0xx_it.h"

void ui_button_pressed(uint8_t button);
void set_pressure_offset(uint16_t press);
void failure_proc(void);
uint8_t *get_system_error(void );
uint8_t *get_current_cushion(void);
void set_automatic_operation(uint8_t op);
uint8_t get_automatic_operation(void);
void led_operation_work(void);
void set_led_operation_work(uint8_t op);
void ui_button_released(uint8_t button);
#endif
