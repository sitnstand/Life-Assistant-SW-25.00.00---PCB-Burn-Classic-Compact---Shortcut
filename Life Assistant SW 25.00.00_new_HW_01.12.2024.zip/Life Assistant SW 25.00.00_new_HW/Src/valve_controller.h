#ifndef __VALVE_CONTROLLER_H
#define __VALVE_CONTROLLER_H


#define VALVE_CUSHION_1  0
#define VALVE_CUSHION_2  1
#define VALVE_CUSHION_3  2
#define VALVE_CUSHION_4  3




#define VALVE_FORWARD 1
#define VALVE_BACKWARD 2

uint8_t *get_valve_pwm_c_r(void);
uint8_t *get_valve_pwm_c_l(void);
void OpenValve(void * period);
void StopValve(void * op);
void ResetAllValves(void);
void SetAllValves(void);
void InitDumiTask(void);
void InitOpenValveTask(void);
void InitStopValveTask(void);
void changeValvePosition(uint8_t valve,MotorState dir);
void CloseAllValvsTask(void *op);
void InitCloseAllValvsTask(void);
uint8_t is_valve_ready(void);
bool CheckGpioBeforToggle(uint8_t cushoinValve,MotorState dir);
TaskHandle *GetStopValveTaskTaskID(void);
uint8_t *Get_valve_ready_flag(void);
void FinalDeflateTask(void *op);
void InitFinalDeflateTaskTask(void);
TaskHandle *GetFinalDeflateTaskTaskID(void);
void close_all_valves(void);
void open_all_valves(void);
#endif


