#include "include_all_headers.h"

static TaskHandle SaveDataToFlashTaskID;

LogDataStruct loggerData;

/*
	Should be changed to work without software delay
*/

//init save data to flash  task
void InitSaveDataToFlashTask(void)
{		
	SaveDataToFlashTaskID = add_task(&SaveDataToFlashTask);	
	
	readDataFromFlash();
}

void readDataFromFlash(void)
{
	flash_read(0, (uint8_t*)&loggerData, sizeof(loggerData));	
		
	if(loggerData.currCusion == 0xff || loggerData.watchDogCnt == 0xffff)
	{
	loggerData.currCusion	  = 0;
	loggerData.maxPressure 	= 0;
	loggerData.valve1Cnt 		= 0;
	loggerData.valve2Cnt 		= 0;
	loggerData.valve3Cnt 		= 0;
	loggerData.valve4Cnt 		= 0;
	loggerData.valve5Cnt 		= 0;
	loggerData.watchDogCnt 	= 0;
	loggerData.pumpWorkTime = 0;
	loggerData.errorFlag 		= 0;
		
	for(int i=0; i < NUM_OF_CUSIONS; i++)
	{		
		loggerData.valveState[i]  = VALVE_UNKNOWN;
	}
	
	saveDataToFlash();
	}
	
	//Restore cushion state
	*get_current_cushion() = loggerData.currCusion;
	
	if(loggerData.watchDogCnt >= 1)
	{
		loggerData.errorFlag = 1;
	}
	
	*get_system_error() = getLoggStructPtr()->errorFlag;
}

LogDataStruct* getLoggStructPtr(void)
{
	return &loggerData;
}

void saveDataToFlash(void)
{
	WriteRecordToFlash(0, (uint8_t*) &loggerData, sizeof(loggerData));
}
	
TaskHandle *GetSaveDataToFlasfTaskID(void)
{
	return &SaveDataToFlashTaskID;
}

void SaveDataToFlashTask(void *op)
{
	TimeStamp StartSaveToFlashTime = *UtilitiesGetSystemClock();
	// save to flash only if the hardware drivers ready and the SW not in othe process.
	if(!mainControllerInfo.deviceState.MainControllerTaskWork  && *Get_valve_ready_flag() == 1)
	{
		printf("*** Saving the state...***\r\nSystem clock -> Sec = %d, Mili = %d\r\n",StartSaveToFlashTime.seconds,StartSaveToFlashTime.mili);
		
		saveDataToFlash();
		
		printf("***State saved. ***\r\nSystem clock -> Sec = %d, Mili = %d\r\n",StartSaveToFlashTime.seconds,StartSaveToFlashTime.mili);
	}else
	{
		printf("*** Flag not ready***\r\n\r\n\r\n");
	}
}

void SaveCurrentCushionToFlash(void)
{
	TimeStamp StartSaveToFlashTime = *UtilitiesGetSystemClock();
	// save to flash only if the hardware drivers ready and the SW not in othe process.
	if(!mainControllerInfo.deviceState.MainControllerTaskWork  && *Get_valve_ready_flag() == 1)
	{
		
		cancel_task(*GetSaveDataToFlasfTaskID());
		exec_task(*GetSaveDataToFlasfTaskID(), WAIT_TIME_TO_SAVE_DATA_AFTER_PROCESS, 0, (void*) NULL);	// save the date on flash after 1 minute 
		printf("*** Will save to flash in %d Seconds***\r\n",WAIT_TIME_TO_SAVE_DATA_AFTER_PROCESS/1000);
	}else
	{
		printf("*** Flag not ready ***");
	}
}

void cancel_save_to_flash(void)
{
		printf("\r\nCanceling save to flash task\r\n");
	cancel_task(*GetSaveDataToFlasfTaskID());
}

void ReadCurrentCusionFromFlash(void)
{
	uint8_t curr_cushion = 0;
	
	curr_cushion = loggerData.currCusion;
	
	if(curr_cushion <= 5)
	{
		*get_current_cushion() = curr_cushion;
	}else
	{
		*get_current_cushion() = 0;
		//WriteRecordToFlash(0, (uint8_t*) &(*get_current_cushion()),sizeof((*get_current_cushion())));
	}
	//flash_read(0,(uint8_t*)&(*get_current_cushion()), sizeof(*get_current_cushion()));		
}


HAL_StatusTypeDef WriteRecordToFlash(uint32_t address, uint8_t* data,uint16_t size)
{
	HAL_StatusTypeDef status = HAL_ERROR;
	
	status = flash_erase( (uint32_t)address + FLASH_ADD, TYPEERASE_PAGES );
	
	if(status == HAL_OK)
	{
		status = flash_write( 0, data, size);
	}
	return status;
}


/* Flash erase */
HAL_StatusTypeDef flash_erase( uint32_t Address, uint8_t mass)
{
	
	HAL_StatusTypeDef status=HAL_OK;
		
		status = HAL_FLASH_Unlock();
			
				FLASH_WaitForLastOperation(FLASH_TIMEOUT);
	
			__HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPERR);
			
			FLASH_EraseInitTypeDef erase_init;
			uint32_t error=0;
			
			erase_init.PageAddress=Address;
			erase_init.NbPages=1;
			erase_init.TypeErase=mass;
			
      status =  HAL_FLASHEx_Erase(&erase_init, &error);
			FLASH_WaitForLastOperation(FLASH_TIMEOUT);	
			status = 	HAL_FLASH_Lock();
			FLASH_WaitForLastOperation(FLASH_TIMEOUT);	
	
	return status;
}
/* Flash Write */
HAL_StatusTypeDef flash_write( uint16_t Address, uint8_t* Data, uint16_t length)

{
	//Minimum HALF_WORD
	if(length == 1)
	{
		length = 2;
	}
	/*uint16_t buff[(length+1)/2];
	memcpy((uint8_t*)buff,Data,length);
	*/
	
	HAL_StatusTypeDef status = HAL_OK;
	
	status = HAL_FLASH_Unlock();
	FLASH_WaitForLastOperation(FLASH_TIMEOUT);
	if(status != HAL_OK){
		return status;
	}
	
        __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPERR);
	
	for(uint16_t i = 0; i < length/2 ; i++){
		
		status = HAL_FLASH_Program(TYPEPROGRAM_HALFWORD, FLASH_ADD + Address + i*2, *(uint16_t*)(Data + i*2));
	
		if(status != HAL_OK){
			return status;
		}
		
	}
	FLASH_WaitForLastOperation(FLASH_TIMEOUT);
	HAL_FLASH_Lock();
	FLASH_WaitForLastOperation(FLASH_TIMEOUT);	
	return status;
	
}

/* Flash Read */
void flash_read(uint16_t address, uint8_t *data, uint16_t length)
{
 	memcpy(data, (uint8_t*)(FLASH_ADD + address), length);
}



