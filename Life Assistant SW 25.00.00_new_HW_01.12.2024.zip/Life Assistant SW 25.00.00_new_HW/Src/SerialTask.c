///////////////////////////////////////////////////////////////////////////////
// Source file SerialTask.c
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2021, Zoosmanovskiy Lev.
// Serial communication task source
///////////////////////////////////////////////////////////////////////////////

#include "SerialTask.h"
#include "selfTest.h"
#include "protocol.h"

#define SERIAL_TASK_PERIOD 1
TaskHandle SerialTaskHndl;

static Message  RxMessage;
static MsgState msgState = etMsgStateWaitingForPreamble;
static uint32_t _bad_crc_cnt = 0;

void validMsgHandler(Message* msg);


void SerialTask(void * ptr);

//init Main Serial task
int SerialInit(void)
{
		SerialTaskHndl = add_task(&SerialTask);
	
		exec_task(SerialTaskHndl, SERIAL_TASK_PERIOD, 1, 0);
	
return 0;
}
	

void validMsgHandler(Message* msg)
{
  
  switch(msg->opcode)
    {
      
			case OpcodeGetInfo:
				ProtocolSendMessage(DevTypePC , OpcodeAck, 0, 0);
      break;
			
			case OpcodeStartTest:
			if(isInTest() == 0)	
				testStart();
				break;
			case OpcodeCancelTest :
						testCancel();
			break;
			case OpcodeExtValveOp:
			
				if(msg->data[0] == 1)
				{
					EXT_VALVE_ON();
				}
					else
					{
						EXT_VALVE_OFF();
					}
					
			break;
			case	OpcodeOpenValve:
			case OpcodeCloseValve:
				changeValvePosition(msg->data[0], (MotorState)msg->data[1]);
			break;

			case OpcodeStartPump:
			PumpStart();
			//pwm_set_duty_cycle(30);
			break;
		case OpcodeStopPump:
			PumpStop();

			break;
    case OpcodeAck:
      break;
		
		default:
			break;
	}
}

void SerialTask(void * ptr)
{
uint32_t curr_time = HAL_GetTick();
  static tCircularBuffer*  ProtocolCircBuffer;
  // TODO: add xSemaphoreTake() 
  
  ProtocolCircBuffer = usartGetCircBuff();
  
  int bufferFilled = GetBufferSize(ProtocolCircBuffer);
  
  
  if (bufferFilled)
  {
    
    uint16_t          numBytes;
    
    uint8_t rxByte = 0;
    
    // get the number of available bytes to process
    numBytes = bufferFilled;
    // check if there's any serial port data to process
    
    while (numBytes > 0)
    {
      //Pull one byte out of the buffer
      ReadBuffer(ProtocolCircBuffer, (unsigned char*)&rxByte, 1);
      //Feed the protocol parser byte by byte
      msgState = (MsgState)ProtocolParseMsg(&RxMessage, rxByte);
      //If message ready
      if (msgState == etMsgStateMessageReady)
      {
        //Validate CRC
        
        if (ProtocolMessageValidateCrc(&RxMessage, RxMessage.crc))
        {
          //Handle validated message
          validMsgHandler(&RxMessage);
          
          //          lastCommunicationEventTime = HAL_GetTick();
          //clear the container
          memset(&RxMessage, 0, sizeof(Message));
        }
        else
        {
          _bad_crc_cnt++;
        }
        msgState = etMsgStateWaitingForPreamble;
        break;
      }
      numBytes--;
    }
  }
  else //if no data
  {
    //Interrupt force re-enable (Should not happen)
    if (0)//!(USART1->CR1 & USART_CR1_RXNEIE_RXFNEIE))
    {
      // UpdateWritePtr(ProtocolCircBuffer, 1);
      
      HAL_UART_Receive_IT(UartGetHuart1Struct(), GetWritePtr(ProtocolCircBuffer), 1);
    }
  }
}
	

