#ifndef __SW_CONFIGURATION_H
#define __SW_CONFIGURATION_H

//a2d
#define VREF_VOLTAGE 												  3300
#define MAX_A2D_VALUE 											  4096
#define ADC_TIMEOUT 												  500


//pump
//Waiting (or not) before starting the pressure sampling
#define  WAIT_BEFORE_START_PRESSURE 					true //false
//Pressure sampling and before incrase PWM
#define TIME_BEFORE_SAMPLING_PRESSURE     		2000
#define MIN_TIME_INFLATION                    1000
#define MAX_TIME_INFLATION 										5000
#define DELAY_TO_START_SAMPLE_PRESSURE        300
#define MIN_PUMP_VOLUME												30



//This values  are not relevant to the valves opening and closing sequence.
//they are for te dash board
//opening sequence
#define VALVE_TOTAL_OPENING_TIME 						        160 // total valve work time 
//closing sequence 
#define VALVE_TOTAL_CLOSING_TIME 						 				140  // total valve work time 



#define CLOSE_ALL_VALVES_AT_THE_END 			0       
  

//Opening timing
#define OPENING_TIME_BEFORE_BRAKE					40  // it was 40 01.03.2020
#define OPENING_TIME_BRAKE								150  // it was 300 01.03.2020
#define OPENING_TIME_PWM_BEFORE_STOP			150 // it was 70 01.03.2020
#define OPENING_PWM_PERCENT								20  // it was 30 01.03.2020

//Closing timing
#define CLOSING_TIME_BEFORE_BRAKE					0   // it was 30 01.03.2020
#define CLOSING_TIME_BRAKE								0   // it was 300 01.03.2020
#define CLOSING_TIME_PWM_BEFORE_STOP			300 // it was 100 10.02.2021
#define CLOSING_PWM_PERCENT								50  // it was 60 10.02.2021


#define DESIRED_PRESSURE_VALUE						250 // it was 260



#define SAMPLES_BEFORE_STOP 500



//led's 
#define TIME_AFTER_PUMP_SPIKE                 1000




#define PWM_TIME_STEP   											30   //Milli //Longer time means slower PWM rising
#define PWM_TIME_STEP_BOOST										30   //Milli
#define PWM_PUMP_STEP 												2    //percent
#define PWM_PUMP_STEP_BOOST										2    //percent
#define PWM_PUMP_START_PERCENT								10   //percent
#define MAX_PWM_PERCENT                       75   //percent
#define PWM_BOOST_THRESHOLD 									10000 //time (milli)
#define PWM_BOOST_TARGET 											100	 //percent


//main controller
#define NUM_OF_CUSIONS												4
#define PWM_VALVE_OPEN_START_POWER           	100 // power on the start
#define PWM_VALVE_CLOSE_START_POWER          	100 // power on the start      
#define DELAY_AFTER_PUMP_STOP									100 // between the pump stop and the closing the valve 
#define FINAL_DEFLATE_TIME 										3000
#define MAX_TIME_VALVE_MOTOR_WORK 						100
#define TIME_TO_DEFLATION 										5000
#define T1_IDLE_TIME													150
//New for the automatic operation
#define T2_IDLE_TIME													1000
#define T3_IDLE_TIME													3000


#define MAX_TIME_TO_INFLATION 								15000

#define TIME_BETWEEN_2_BUTTON_CLICK 					100
#define P0_ABSOLUTE_VALUE 										550
 
#define WAIT_TIME_TO_SAVE_DATA_AFTER_PROCESS  100


//Battery low threshold (millivolts)
#define BATTERY_THRESHOLD_LED  14000
#define BATTERY_THRESHOLD_MAX  15000
#define BATTERY_THRESHOLD_MIN  13000



//sleep mode 
// the system wait 1 min 
// after the last button 
// event to entry to sleep mode 
#define TIME_BEFOR_SLEEP_MODE                  60000         

#define TIME_TO_PRESS_FOR_RELEASE_FAILURE       5000
//Time to press on both buttons for test mode
#define TIME_TO_PRESS_FOR_TEST_MODE			  		 15000

#define TIME_BETWEEN_INFLATE_DEFLATE_TEST_MODE	1500

#define LED_IN_WORK_ON_TIME          					   200
#define LED_IN_WORK_OFF_TIME                     200

#define LED_IN_IDLE_ON_TIME                      100
#define LED_IN_IDLE_OFF_TIME                    2000

//LED's blink at startup
#define LED_STARTUP_ON_TIME                      100
#define LED_STARTUP_OFF_TIME                     200


#define LED_ERROR_BLINK_PERIOD	                 100

#define BATTERY_LEVEL_PRINT_PERIOD              5000
#endif









