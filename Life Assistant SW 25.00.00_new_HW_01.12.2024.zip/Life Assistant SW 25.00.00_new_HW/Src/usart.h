#ifndef __USART_H
#define __USART_H

#include "include_all_headers.h"
#include "circ_buff.h"

#define RX_CYCLIC_BUFFER_SIZE      0x100
#define RX_CYCLIC_BUFFER_SMASK     0xff

#define MIN_LINE_LENGTH 6
#define FAILURE 0
#define SUCCESS 1

#define UART1 1
#define UART2 2

// protocol define's
#define GET_SYSTEM_TIME_CMD "stime"
#define DEFLATE_CMD					"deflate"
#define DSYSTEM_INFO_CMD    "sinfo"

typedef struct{

	char name[10];
	char args[3][10];
	uint8_t argsNum;
	
}Command;

typedef struct
{
  uint8_t RxCyclicBuffer[RX_CYCLIC_BUFFER_SIZE];
  uint8_t RxCyclicBufferIndex;
  uint8_t RxCyclicBufferLastLineIndex;	
  uint8_t RxCyclicBufferMark;
  char RxLine[RX_CYCLIC_BUFFER_SIZE];
  Command RxCommand;
}UartInfoType;






extern UartInfoType uartInfo;
extern UART_HandleTypeDef huart1;




void RxCommandTask(void *op);
void InitRxCommandTask(void);
void InitUsart(void);
UART_HandleTypeDef * UartGetHuart1Struct(void);
uint8_t uart_send(uint8_t uart, uint8_t *data, uint16_t len);

tCircularBuffer* usartGetCircBuff(void);
void uart_print_ascii(uint8_t*);
void uart_print_msg(uint8_t * str, uint16_t len);
void uartPutData(UART_HandleTypeDef *huart, uint8_t *data, uint32_t length);
uint8_t prefix(const char *pre, const char *str);
void AnalyzyPcCommand(void);

#endif
